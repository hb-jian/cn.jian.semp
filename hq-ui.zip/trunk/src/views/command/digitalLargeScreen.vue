<template>
  <div class="list-box">
    <div style="height: 42px">
      <el-button type="primary" size="small" @click="fullScreen">全屏显示</el-button>
    </div>
    <iframe style="width: 100%; height: 100%;border-radius: 3px;" frameborder="no" id="template-iframe" ref="iframe" :src="screenSrc"></iframe>
  </div>
</template>

<script>
  export default {
    name: 'digitalLargeScreen',
    data() {
      return {
        screenSrc: 'https://share.shanhaibi.com/620a076dcedf1/'
      }
    },
    methods: {
      fullScreen() {
        window.open(this.screenSrc)
      }
    }
  }
</script>

<style scoped>
  .list-box {
    padding: 15px 15px 0 15px;
    width: calc(100% - 30px);
    height: calc(100% - 82px);
  }
  .pagination-box {
    height: 52px;
    padding: 15px 20px 0 0;
    float: right;
  }
</style>
