<template>
  <div class="warp-box">
    <div class="box">
      <div class="left" v-if="!$route.query.fullscreen" :style="{width: `${leftWidth}px`}">
        <div class="menu-box" ref="menuBox">
          <div class="title-box" ref="titleBox">
            <div>监控中心</div>
            <div @click="setFullScreen">
              <img src="@/assets/img/cast.png">
              <div>投屏</div>
            </div>
          </div>
          <div class="menu-comp" :style="{height: `${menuHeight}px`}">
            <Menu
              ref="menu"
              :isMonitor="true"
              :showPushing="true"
              :disableFlag="true"
              :disableAll="disableAll"
              @itemClick="handleItemClick"></Menu>
          </div>
        </div>
      </div>
      <div class="right">
        <div class="left-toggle" @click="toggleLeftBox">
          <i class="el-icon-arrow-left" v-if="isLeftSpread"></i>
          <i class="el-icon-arrow-right" v-else></i>
        </div>
        <div class="right-wrapper">
          <div class="right-header">
            <div>显示数量：</div>
            <div class="display-btn-box">
              <div
                @click="changeDislay(i)"
                :class="currentDisplayNum == i ? 'active' : ''"
                v-for="i in displayNumList"
                :key="i">{{i}}</div>
            </div>
            <div style="flex-grow: 1;"></div>
            <div class="save-layout">
              <div class="btn" @click="saveLayout">保存布局</div>
            </div>
          </div>
          <div class="right-content">
            <div class="screen-box" :style="screenBoxStyle" ref="screenBox">
              <div :style="screenStyle" v-for="(item, index) in screenList" :key="index">
                <Screen
                  :ref="`screen_${index}`"
                  :info="{...item, index}"
                  @screenClose="handleScreenClose"
                  @screenClick="handleScreenClick"></Screen>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
  import Menu from '@/components/menu/Menu'
  import Screen from '@/components/screen/Index'
  import { requestFullScreen } from '@/util/utils'
  export default {
    name: 'monitoring',
    data() {
      return {
        displayNumList: [1, 2, 4, 9, 16],
        //  初始化显示的屏幕的个数
        currentDisplayNum: 9,
        //  当前选中的屏幕
        currentSelectNum: 0,
        screenList: [],
        calcScreenHeight: 0,
        gapMap: {
          1: 0,
          2: 1,
          4: 1,
          9: 2,
          16: 3
        },
        //  每个屏幕之间的距离
        screenGap: 10,
        screenWidth: 0,
        everyScreenWidth: 0,
        everyScreenHeight: 0,

        leftWidth: 370,
        isLeftSpread: true,

        isLoaded: false,
        menuHeight: 0,

        layoutInfo: 'layoutInfo',
        screenMap: {},

        //  禁止菜单选择
        disableAll: false
      }
    },
    watch: {
      currentDisplayNum() {
        this.saveTmpLayout()
      },
      currentSelectNum() {
        this.saveTmpLayout()
      }
    },
    computed: {
      screenStyle() {
        return {
          width: `${this.everyScreenWidth}px`,
          height: `${this.everyScreenHeight}px`
        }
      },
      screenBoxStyle() {
        return {
          height: `${this.calcScreenHeight}px`,
          alignContent: this.currentDisplayNum == 2 ? 'center' : 'space-between'
        }
      }
    },
    methods: {
      toggleLeftBox() {
        this.leftWidth = this.isLeftSpread ? 0 : 370
        this.isLeftSpread = !this.isLeftSpread

        this.$nextTick(() => {
          this.reCalcScreen()
        })
      },

      handleItemClick(item) {
        let tmp = JSON.parse(JSON.stringify(item))
        if(!item.isFolder) {
          const selectedScreen = this.screenList.find(i => i.selected == true)
          if(tmp.isChecked) {
            //  当前选中实例
            const currentScreen = this.$refs[`screen_${this.currentSelectNum}`][0]
            this.screenMap[item.id] = {currentScreen}

            const url = this.getM3U8url(item.playUrls)
            const name = item.name
            this.setScreenUrl(url, name, item.id)
          } else {
            //  取消对应窗口视频
            this.screenMap[item.id].currentScreen.handleClose()
          }
        }
      },

      getM3U8url(urls) {
        return urls.find(i => i.streamtype === 'm3u8').url
      },

      changeDislay(val) {
        if(val === this.currentDisplayNum) return
        const reducedNum = this.currentDisplayNum - val

        //  当少屏全部在播放，切换到多屏时，选择下一个屏幕
        if(reducedNum < 0 && this.isAllPlaying()) {
          this.currentSelectNum = this.currentDisplayNum
        }

        this.currentDisplayNum = val
        //  屏幕数增加
        const len = this.screenList.length
        const oldScreenList = this.screenList.slice(0)
        if(val > len) {
          this.genScreenList(val - len)
        } else {
          this.screenList.length = val
        }

        //  判断是否可以选择
        this.isFullFilled()

        //  从多屏向少屏切换时，如果当前选择分屏在少屏中不存在，则选中最后一个屏幕
        if(this.currentSelectNum >= this.currentDisplayNum) {
          this.currentSelectNum = this.currentDisplayNum - 1
        }
        this.handleScreenClick({index: this.currentSelectNum})

        //  多屏调整为少屏，多出部分的监控地址将从菜单列表中移除（取消选中）
        if(reducedNum > 0) {
          let tmp = reducedNum
          for(let i = reducedNum;i > 0; i--) {
            let item = oldScreenList[i]
            if(item.url) {
              this.$refs.menu.removeChecked(item.id)
            }
          }
        }

        this.calcScreenWidth()
      },

      //  判断当前全部屏幕是否全部具有url
      isAllPlaying() {
        const len = this.screenList.length
        return this.screenList.filter(i => i.url).length === len
      },

      //  根据需要显示的屏幕个数，计算每个显示组件的宽高
      calcScreenWidth() {
        const gapNum = this.gapMap[this.currentDisplayNum]
        const totalGapWidth = gapNum * this.screenGap
        //  每一个显示屏组件的宽度
        this.everyScreenWidth = (this.screenWidth - totalGapWidth) / (gapNum + 1)
        this.everyScreenHeight = this.everyScreenWidth / (16 / 9) - 1/* 矫正计算时，产生的小数像素偏差 */
      },

      calcScreenBox() {
        const screenWidth = this.screenWidth = this.$refs.screenBox.offsetWidth
        this.calcScreenHeight = screenWidth / (16 / 9)
      },

      createScreenList() {
        this.genScreenList(this.currentDisplayNum)
      },

      genScreenList(i) {
        while(i --) {
          this.screenList.push({
            selected: false,
            url: '',
            name: '',
            id: ''
          })
        }
      },

      handleScreenClick(val) {
        const index = val.index
        this.screenList.forEach(item => item.selected = false)
        this.screenList[index].selected = true
        this.currentSelectNum = index
      },

      //  关闭分屏时，清空播放地址
      handleScreenClose(val) {
        this.$refs.menu.removeChecked(val.id)
        this.screenList[val.index].url = ''
        this.isFullFilled()
      },

      setScreenUrl(url, name, id) {
        const selectedScreen = this.screenList.find(i => i.selected == true)
        if(selectedScreen) {
          selectedScreen.url = url
          selectedScreen.name = name
          selectedScreen.id = id
        }
        //  判断是否可以选择
        this.isFullFilled()

        //  焦点移动到下一个可选择的屏幕
        this.moveTonextSelectableScreen()
      },

      isFullFilled() {
        if(this.screenList.filter(item => !!item.url).length >= this.currentDisplayNum) {
          this.disableAll = true
        } else {
          this.disableAll = false
        }
      },

      moveTonextSelectableScreen() {
        let i = 0
        let nextSelectableIndex
        let next = this.currentSelectNum
        //  找到下一个可选择的屏幕
        while(++i && i <= this.currentDisplayNum && (nextSelectableIndex == undefined)) {
          next = (next + 1) == this.currentDisplayNum ? 0 : ++next
          if(!this.screenList[next].url) {
            nextSelectableIndex = next
          }
        }
        if(nextSelectableIndex !== undefined) {
          this.handleScreenClick({index: nextSelectableIndex})
        }
      },

      setFullScreen() {
        requestFullScreen(this.$refs.screenBox)
      },

      reCalcScreen() {
        this.calcScreenBox()
        this.calcScreenWidth()
      },

      /**
       * 获取布局信息
       */
      getLayoutInfo() {
        return JSON.stringify({
          currentDisplayNum: this.currentDisplayNum,
          currentSelectNum: this.currentSelectNum
        })
      },

      saveTmpLayout() {
        sessionStorage.setItem(this.layoutInfo, this.getLayoutInfo())
      },

      /**
       * 保存布局信息为默认信息
       */
      saveLayout() {
        localStorage.setItem(this.layoutInfo, this.getLayoutInfo())
      },

      /**
       * 获取布局信息
       */
      getCachedLayout() {
        //  首先采用sessionStorage中的信息，如果不存在，使用localStorage中的信息
        const layoutInfo = sessionStorage.getItem(this.layoutInfo)
        if(layoutInfo) {
          const info = JSON.parse(layoutInfo)
          this.currentDisplayNum = info.currentDisplayNum
          this.currentSelectNum = info.currentSelectNum > info.currentDisplayNum ? 0 : info.currentSelectNum
        } else {
          const localLayoutInfo = localStorage.getItem(this.layoutInfo)
          if(localLayoutInfo) {
            let info = JSON.parse(localLayoutInfo)
            this.currentDisplayNum = info.currentDisplayNum
            this.currentSelectNum = info.currentSelectNum > info.currentDisplayNum ? 0 : info.currentSelectNum
          }
        }
      }
    },
    created() {
      const resizeFn = () => this.reCalcScreen()
      window.addEventListener('resize', resizeFn)
      this.$once('hook:beforeDestroy', () => window.removeEventListener('resize', resizeFn))

      //  获取缓存的布局，如果存在，应用缓存中布局
      this.getCachedLayout()

      //  创建屏幕布局
      this.createScreenList()
      //  默认选中已缓存布局
      this.handleScreenClick({index: this.currentSelectNum})
    },
    mounted() {
      // eventNotice.on('ID_EVT_TABCLICKED', res => {
      //   let page = JSON.parse(res).page
      //   if(!this.isLoaded && page == 'monitor') {
      //     this.isLoaded = true
      //     const timer = setInterval(() => {
      //       if(document.body.clientHeight > 500) {
      //         clearInterval(timer)
      //         this.menuHeight = this.$refs.menuBox.clientHeight - this.$refs.titleBox.clientHeight
      //       }
      //     }, 50)
      //   }
      // })
      this.reCalcScreen()
    },
    components: {
      Menu, Screen
    }
  }
</script>

<style lang="less" scoped>
  ::-webkit-scrollbar-thumb {
    border-radius: 10px;
    /*box-shadow: inset 0 0 0px rgba(240, 240, 240, .5);*/
    background-color: rgba(79,172,250,.5);
  }
  .warp-box {
    padding: 12px 0 0 12px;
    width: calc(100% - 30px);
    height: calc(100% - 25px);
    .box {
      min-width: 1000px;
      height: 100%;
      color: #fff;
      background: #06041c;
      overflow-y: scroll;
      display: flex;
      .left {
        overflow: hidden;
        // transition: width .1s linear;
        width: 370px;
        height: 100%;
        .menu-box {
          width: 360px;
          height: 100%;
          border-right: 1px solid #48A2B3;
          display: flex;
          flex-direction: column;
          .title-box {
            height: 66px;
            display: flex;
            align-items: center;
            &>div:first-child {
              flex-grow: 1;
              padding-left: 10px;
            }
            &>div:last-child {
              display: flex;
              align-items: center;
              margin-right: 20px;
              background: #003B68;
              border: 1px solid #48A2B3;
              border-radius: 4px;
              font-size: 14px;
              padding: 6px 16px;
              cursor: pointer;
              color: #A9DDEE;
              &:hover {
                background: #48A2B3;
              }
              img {
                margin-right: 3px;
              }
            }
          }
          .menu-comp {
            height: 0;
            flex-grow: 1;
            overflow: auto;
          }
        }
      }
      .right {
        flex-grow: 1;
        width: 0;
        border-left: 1px solid #48A2B3;
        position: relative;
        .left-toggle {
          color: #eee;
          position: absolute;
          z-index: 10000;
          width: 16px;
          height: 60px;
          line-height: 60px;
          cursor: pointer;
          background: rgba(0, 0, 0, 0.4);
          top: 350px;
          border-radius: 0 8px 8px 0;
          left: 0;
          &:hover {
            background: rgba(0, 0, 0, 0.8);
            color: #fff;
          }
        }
        .right-wrapper {
          height: 100%;
          display: flex;
          flex-direction: column;
          .right-header {
            padding-left: 20px;
            display: flex;
            align-items: center;
            height: 74px;
            font-size: 14px;
            border-bottom: 1px solid #48A2B3;
            .display-btn-box {
              display: flex;
              align-items: center;
              &>div {
                user-select: none;
                width: 32px;
                height: 32px;
                text-align: center;
                line-height: 32px;
                color: #666666;
                background: #fff;
                border-radius: 4px;
                margin-right: 5px;
                cursor: pointer;
                transition: all .1s linear;
                &.active, &:hover {
                  background: #01D4F9;
                  color: #fff;
                }
              }
            }
            .save-layout {
              padding: 0 20px;
              .btn {
                user-select: none;
                background: linear-gradient(#2DBCDD, #1898B6, #2DBCDD);
                opacity: 0.8;
                padding: 5px 10px;
                border-radius: 3px;
                cursor: pointer;
                color: #fff;
                &:hover {
                  opacity: 1;
                }
              }
            }
          }
          .right-content {
            flex-grow: 1;
            height: 0;
            padding: 10px;
            display: flex;
            justify-content: center;
            background: #0F1747;
            &>div {
              width: 100%;
            }
            .screen-box {
              display: flex;
              align-items: center;
              justify-content: space-between;
              background: #0F1747;
              flex-wrap: wrap;
            }
          }
        }
      }
    }
  }
</style>
