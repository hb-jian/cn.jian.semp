<template>
  <el-dialog
    :title="title"
    :visible.sync="dialogVisible"
    :before-close="handleClose">
    <el-divider></el-divider>
    <el-form ref="enterpriseModel" :model="enterpriseModel" :rules="enterpriseRules" label-width="120px">
      <el-form-item label="管理员账号：" prop="admin" v-if="!isEdit">
        <el-input size="small" style="width: 75%" v-model="enterpriseModel.admin"></el-input>
      </el-form-item>
      <el-form-item label="密码：" prop="pwd" v-if="!isEdit">
        <el-input size="small" style="width: 75%" v-model="enterpriseModel.pwd"></el-input>
      </el-form-item>
      <el-form-item label="昵称：" prop="name">
        <el-input size="small" style="width: 75%" v-model="enterpriseModel.name"></el-input>
      </el-form-item>
      <el-form-item label="企业大屏地址：">
        <el-input size="small" style="width: 75%" v-model="enterpriseModel.dataViewUrlOfOrg"></el-input>
      </el-form-item>
      <el-form-item label="项目大屏地址：">
        <el-input size="small" style="width: 75%" v-model="enterpriseModel.dataViewUrlOfProject"></el-input>
      </el-form-item>
      <el-form-item label="企业菜单：">
        <el-button type="primary" icon="el-icon-menu" size="small" circle @click="selectMenu"></el-button>
      </el-form-item>
    </el-form>
    <span slot="footer" class="dialog-footer">
        <el-button @click="cancel" size="small">取 消</el-button>
        <el-button type="primary" size="small" @click="submit">确 定</el-button>
      </span>
    <uib-modal v-if="showModal" v-on:closeme="closeme" :selectedData="selectedData"
               v-on:confirmSelected="confirmSelected"></uib-modal>
  </el-dialog>
</template>

<script>
  import uibModal from '../../components/uibModal/selectMenuModal'
  import api from '@/api/'

  export default {
    name: "EnterpriseCreate",
    props: ['visibleType', 'dataInfo','isEdit'],
    components: {
      uibModal
    },
    data() {
      return {
        dialogVisible: false,
        title: '新增企业',
        showModal: false,
        selectedData: [],
        enterpriseModel: {
          admin: '',//账号
          name: '',//昵称
          pwd: '',//密码
          dataViewUrlOfOrg: '',//企业大屏地址
          dataViewUrlOfProject: '',//项目大屏地址
          id: '',//企业编号，更新操作时必须携带
          menus: []
        },
        enterpriseRules: {
          admin: [{required: true, message: '请输入管理员账号', trigger: 'blur'},
            {min: 6, max: 16, message: '长度在 6 到 16 个字符', trigger: 'blur'}],
          pwd: [{required: true, message: '请输入密码', trigger: 'blur'},
            {min: 8, max: 16, message: '长度在 8 到 16 个字符', trigger: 'blur'}],
          name: [{required: true, message: '请输入账号昵称', trigger: 'blur'}]
        }
      }
    },
    created() {
    },
    watch: {
      visibleType(val) {
        this.dialogVisible = val
        if (val) {
          this.initDataInfo()
        }
      },
      dataInfo(newval, oldval) {
        // console.log(newval, oldval)
      }
    },
    methods: {
      /**
       *  初始化数据信息
       */
      initDataInfo() {
        console.log(this.dataInfo,'==============')
        if (this.isEdit) {
          this.title = '编辑企业'
        }else {
          this.title = '新增企业'
        }
        this.enterpriseModel = {
          admin: this.dataInfo.admin,//账号
          name: this.dataInfo.name,//昵称
          pwd: this.dataInfo.pwd,//密码
          dataViewUrlOfOrg: this.dataInfo.dataViewUrlOfOrg,//企业大屏地址
          dataViewUrlOfProject: this.dataInfo.dataViewUrlOfProject,//项目大屏地址
          id: this.dataInfo.id,//企业编号，更新操作时必须携带
          menus: this.dataInfo.menus
        }
      },
      /**
       * 菜单选择事件
       */
      selectMenu() {
        this.showModal = !this.showModal;
      },

      /**
       * 提交 关闭模态框 并返回携带的值
       */
      confirmSelected(data,halfData) {
        this.selectedData = data;
        let selectedArr = [];
        if (data.length > 0) {
          data.forEach(item => {
            selectedArr.push({
              id: item,
              halfChecked: false
            })
          })
        }
        if (halfData.length > 0) {
          halfData.forEach(item => {
            selectedArr.push({
              id: item,
              halfChecked: true
            })
          })
        }
        this.enterpriseModel.menus = selectedArr;
        console.log(this.enterpriseModel.menus,'====menus====');
        this.showModal = !this.showModal;
      },
      /**
       *  关闭模态框
       */
      closeme() {
        this.showModal = !this.showModal;
      },
      /**
       * 关闭模态框
       * @param done
       */
      handleClose(done) {
        this.$confirm('确认关闭？')
          .then(_r => {
            done();
            this.$emit('getVisibleType', {type: false, isGetList: false})
          })
          .catch(_ => {
          });
      },
      /**
       * 取消
       * type: 关闭模态框使用
       * isGetList: 是否请求列表接口
       */
      cancel() {
        this.$emit('getVisibleType', {type: false, isGetList: false})
      },
      /**
       * 提交
       * type: 关闭模态框使用
       * isGetList: 是否请求列表接口
       */
      submit() {
        if (this.isEdit) {
          api.OrgUpdate(this.enterpriseModel).then(res => {
            if (res.state.code === '0') {
              this.$emit('getVisibleType', {type: false, isGetList: true})
              this.$message({
                message: '修改成功',
                type: 'success'
              });
            } else {
              this.$message({
                message: '接口调用失败，' + res.state.message,
                type: 'error'
              });
            }
          });
        }else {
          api.OrgCreate(this.enterpriseModel).then(res => {
            if (res.state.code === '0') {
              this.$emit('getVisibleType', {type: false, isGetList: true})
              this.$message({
                message: '创建成功',
                type: 'success'
              });
            } else {
              this.$message({
                message: '接口调用失败，' + res.state.message,
                type: 'error'
              });
            }
          });
        }
      }
    }
  }
</script>

<style>
  body .el-divider--horizontal {
    display: block;
    height: 1px;
    width: 100%;
    margin: -24px 0 20px 0;
  }
</style>
