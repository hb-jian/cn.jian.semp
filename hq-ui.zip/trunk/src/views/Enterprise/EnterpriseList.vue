<template>
  <div class="list-box">
    <div style="height: 52px">
      <el-button type="primary" size="small" @click="openCreate">创建</el-button>
    </div>
    <!--模态框-->
    <enterprise-create
      :visibleType="dialogVisible"
      :dataInfo="dataInfo"
      :isEdit="isEdit"
      @getVisibleType="getVisibleType">
    </enterprise-create>
    <el-table
      ref="multipleTable"
      :data="tableData"
      tooltip-effect="dark"
      style="width: 100%"
      :highlight-current-row="highlightCurrentRow"
      height="calc(100% - 52px)"
      stripe
      @selection-change="handleSelectionChange">
      <el-table-column
        type="selection"
        width="55">
      </el-table-column>
      <el-table-column
        prop="name"
        label="企业名称"
        width="160">
      </el-table-column>
      <el-table-column
        prop="dataViewUrlOfOrg"
        label="企业大屏地址">
        <template slot-scope="scope">
          <div>
            <el-link type="primary" :href="scope.row.dataViewUrlOfOrg" target="_blank">{{ scope.row.dataViewUrlOfOrg
              }}
            </el-link>
          </div>
        </template>
      </el-table-column>
      <el-table-column
        prop="dataViewUrlOfProject"
        label="项目大屏地址"
        show-overflow-tooltip>
        <template slot-scope="scope">
          <div>
            <el-link type="primary" :href="scope.row.dataViewUrlOfProject" target="_blank">{{
              scope.row.dataViewUrlOfProject }}
            </el-link>
          </div>
        </template>
      </el-table-column>
      <el-table-column
        label="操作"
        width="100">
        <template slot-scope="scope">
          <!--<el-button @click="handleClick(scope.row)" type="text" size="small">查看</el-button>-->
          <el-button type="text" size="small" @click="editEnterprise(scope.row)">编辑</el-button>
        </template>
      </el-table-column>
    </el-table>
    <div class="pagination-box">
      <el-pagination
        background
        @size-change="handleSizeChange"
        @current-change="handleCurrentChange"
        :current-page="currentPage"
        :page-sizes="[20, 50, 100]"
        :page-size="pageSize"
        layout="total, sizes, prev, pager, next, jumper"
        :total="totalCount">
      </el-pagination>
    </div>
  </div>
</template>

<script>
  import api from '@/api/'
  import EnterpriseCreate from './EnterpriseCreate'

  export default {
    name: 'EnterpriseList',
    components: {
      EnterpriseCreate
    },
    data() {
      return {
        dialogVisible: false,
        isEdit: false,
        tableData: [],
        currentPage: 1, // 当前页码
        pageSize: 20,   // 默认每页条数
        totalCount: 0,  // 默认显示总数量
        dataInfo: {
          admin: '',//账号
          name: '',//昵称
          pwd: '',//密码
          dataViewUrlOfOrg: '',//企业大屏地址
          dataViewUrlOfProject: '',//项目大屏地址
          id: '',//企业编号，更新操作时必须携带
          menus: []
        }
      }
    },
    props: {
      // 点击高亮当前行
      highlightCurrentRow: {
        type: Boolean,
        default: false,
      },
    },
    created() {
      this.getPage(this.currentPage, this.pageSize);
    },
    methods: {
      /**
       *  打开创建企业模态框
       */
      openCreate() {
        this.dataInfo = {
          admin: '',//账号
          name: '',//昵称
          pwd: '',//密码
          dataViewUrlOfOrg: '',//企业大屏地址
          dataViewUrlOfProject: '',//项目大屏地址
          id: '',//企业编号，更新操作时必须携带
          menus: []
        };
        this.isEdit = false;
        this.dialogVisible = true;
      },
      /**
       * 获取子组件传来的值
       */
      getVisibleType(obj) {
        this.dialogVisible = obj.type
        if (obj.isGetList) {
          this.getPage(1, this.pageSize);
        }
      },
      /**
       * 获取列表数据
       * @param pageNum 页码
       * @param pageSize 每页多少条
       */
      getPage(pageNum, pageSize) {
        let data = {pageIndex: pageNum, pageCount: pageSize}
        api.OrgList(data).then(res => {
          if (res.state.code == 0) {
            this.totalCount = res.pagingRows.totalCount
            this.tableData = res.pagingRows.rows
            this.$message({
              message: '获取企业列表成功',
              type: 'success'
            });
          } else {
            this.$message({
              message: '获取企业列表失败：' + res.state.message,
              type: 'error'
            });
          }
        })
      },
      /**
       * 选中的条数
       * @param val
       */
      handleSelectionChange(val) {
        console.log(`每页 ${val} 条`);
      },
      /**
       * 更改每页显示数
       * @param val
       */
      handleSizeChange(val) {
        console.log(`每页 ${val} 条`);
        this.pageSize = val;
        this.getPage(this.currentPage, this.pageSize);
      },
      /**
       * 翻页
       * @param val
       */
      handleCurrentChange(val) {
        console.log(`当前页: ${val}`);
        this.currentPage = val
        this.getPage(this.currentPage, this.pageSize);
      },

      /**
       * 编辑企业信息
       * @param val
       */
      editEnterprise(data) {
        api.OrgGet({id: data.id}).then(res => {
          console.log(res)
          if (res.state.code === '0') {
            let data = res.data;
            this.dataInfo.admin = data.admin ? data.admin : '';
            this.dataInfo.name = data.name ? data.name : '';
            this.dataInfo.pwd = data.pwd ? data.pwd : '';
            this.dataInfo.dataViewUrlOfOrg = data.dataViewUrlOfOrg ? data.dataViewUrlOfOrg : '';
            this.dataInfo.dataViewUrlOfProject = data.dataViewUrlOfProject ? data.dataViewUrlOfProject : '';
            this.dataInfo.id = data.id ? data.id : '';
            this.dataInfo.menus = data.menus ? data.menus : [];
            this.isEdit = true;
            this.dialogVisible = true;
          } else {
            this.$message({
              message: '获取详情失败' + res.state.message,
              type: 'error'
            });
          }
        })
      },
      /**
       * 点击单元格
       * @param val
       */
      handleBtn(row, column, event, cell) {
        console.log(row)
        console.log(column)
        console.log(event)
        console.log(cell)
      }
    }
  }
</script>

<style>
  .list-box {
    padding: 15px 15px 0 15px;
    width: calc(100% - 30px);
    height: calc(100% - 82px);
  }

  .pagination-box {
    height: 52px;
    padding: 15px 20px 0 0;
    float: right;
  }

  body .el-dialog {
    background: white;
  }
</style>
