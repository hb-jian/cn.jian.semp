<template>
  <div class="list-box">
    <el-table
      ref="multipleTable"
      :data="tableData"
      tooltip-effect="dark"
      style="width: 100%"
      height="100%"
      @selection-change="handleSelectionChange">
      <el-table-column
        type="selection"
        width="55">
      </el-table-column>
      <el-table-column
        label="名称">
        <template slot-scope="scope">
          <div>
            {{ scope.row.name }}
          </div>
        </template>
      </el-table-column>
      <el-table-column
        prop="state"
        label="状态">
        <template slot-scope="scope">
          <div>
            {{ scope.row.state == 1 ? '启用': '禁用' }}
          </div>
        </template>
      </el-table-column>
      <el-table-column
        prop="target"
        label="目标">
      </el-table-column>
      <el-table-column
        label="操作"
        width="240">
        <template slot-scope="scope">
          <el-button @click="handleClick(scope.row)" type="text" size="small">详情</el-button>
          <el-button type="text" size="small">修改</el-button>
          <el-button type="text" size="small">禁用</el-button>
          <el-button type="text" size="small">删除</el-button>
        </template>
      </el-table-column>
    </el-table>
    <div class="pagination-box">
      <el-pagination
        background
        @size-change="handleSizeChange"
        @current-change="handleCurrentChange"
        :current-page="currentPage"
        :page-sizes="[20, 50, 100]"
        :page-size="pageSize"
        layout="total, sizes, prev, pager, next, jumper"
        :total="totalCount">
      </el-pagination>
    </div>
  </div>
</template>

<script>
  export default {
    name: 'Policy',
    data() {
      return {
        tableData: [{
          name: '设备负载告警策略',
          state: '1',
          target: '大北农'
        }],
        currentPage: 1,
        pageSize: 20,
        totalCount: 0
      }
    },
    methods: {
      handleSelectionChange(val) {
        console.log(`每页 ${val} 条`);
      },
      handleSizeChange(val) {
        console.log(`每页 ${val} 条`);
      },
      handleCurrentChange(val) {
        console.log(`当前页: ${val}`);
      },

      /**
       * 详情
       * @param val
       */
      handleClick(val) {
        console.log(val)
      }
    }
  }
</script>

<style scoped>
  .list-box {
    padding: 15px 15px 0 15px;
    width: calc(100% - 30px);
    height: calc(100% - 82px);
  }
  .pagination-box {
    height: 52px;
    padding: 15px 20px 0 0;
    float: right;
  }
</style>
