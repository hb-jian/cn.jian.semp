<template>
  <div class="alarm-box">
    <div class="el-row" style="margin-right: -5px">
      <div class="el-col el-col-24 el-col-xs-24 item-box">
        <div class="el-card box-card is-always-shadow">
          <div class="user-avator">
            <div class="header-item">
              <div style="width: 100%; height: 160px">
                <div id="refrigeration_id" class="header-item-echarts"></div>
              </div>
              <div class="echarts-title">
                <span>制冷量</span>
              </div>
            </div>
            <div class="header-item">
              <div style="width: 100%; height: 160px">
                <div id="heating_id" class="header-item-echarts"></div>
              </div>
              <div class="echarts-title">
                <span>制热量</span>
              </div>
            </div>
            <div class="header-item">
              <div style="width: 100%; height: 160px">
                <div id="power_consumption_id" class="header-item-echarts"></div>
              </div>
              <div class="echarts-title">
                <span>耗电量</span>
              </div>
            </div>
            <div class="header-item">
              <div style="width: 100%; height: 160px">
                <div id="temperature_id" class="header-item-echarts"></div>
              </div>
              <div class="echarts-title">
                <span>温度</span>
              </div>
            </div>
            <div class="header-item">
              <div style="width: 100%; height: 160px">
                <div id="pressure_id" class="header-item-echarts"></div>
              </div>
              <div class="echarts-title">
                <span>压力</span>
              </div>
            </div>
            <div class="header-item">
              <div style="width: 100%; height: 160px">
                <div id="flow_id" class="header-item-echarts"></div>
              </div>
              <div class="echarts-title">
                <span>流量</span>
              </div>
            </div>
          </div>
        </div>
      </div>
      <!--设备状态-->
      <div class="el-col el-col-12 el-col-xs-24 item-box" style="padding-bottom: 10px">
        <div class="el-card box-card is-always-shadow" style="height: 400px; margin-top: 15px;">
          <div class="el-card__header hrader-text">
            <div class="clearfix">
              <span>设备状态</span>
            </div>
          </div>
          <div class="el-card__body" style="height: 320px; overflow: auto;">
            <el-table
              :data="deviceStateData"
              :header-cell-style="{background: '#dddddd',color: '#000000'}"
              border
              style="width: 100%">
              <el-table-column
                prop="name"
                label="名称"
                width="180">
              </el-table-column>
              <el-table-column
                prop="state"
                label="状态"
                width="180">
                <template slot-scope="scope">
                  <div>
                    <span>{{ scope.row.state == 0 ? '异常' : '正常' }}</span>
                  </div>
                </template>
              </el-table-column>
              <el-table-column
                prop="coldOrHot"
                label="制冷/热">
              </el-table-column>
              <el-table-column
                prop="load"
                label="负载">
              </el-table-column>
            </el-table>
          </div>
        </div>
      </div>
      <!--告警-->
      <div class="el-col el-col-12 el-col-xs-24 item-box" style="padding-bottom: 10px">
        <div class="el-card box-card is-always-shadow" style="height: 400px; margin-top: 15px;">
          <div class="el-card__header hrader-text">
            <div class="clearfix">
              <span>告警</span>
            </div>
          </div>
          <div class="el-card__body" style="height: 320px; overflow: auto">
            <el-table
              :data="alarmData"
              :header-cell-style="{background: '#dddddd',color: '#000000'}"
              border
              style="width: 100%">
              <el-table-column
                prop="grade"
                label="等级"
                width="180">
                <template slot-scope="scope">
                  <div>
                    <span>{{ scope.row.grade == 0 ? '提示' : scope.row.grade == 1 ? '警告' : '故障' }}</span>
                  </div>
                </template>
              </el-table-column>
              <el-table-column
                prop="deviceName"
                label="设备"
                width="180">
              </el-table-column>
              <el-table-column
                prop="alarmInfo"
                label="告警">
              </el-table-column>
            </el-table>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
  export default {
    name: "alarm",
    data() {
      return {
        deviceStateData: [
          {
            name: '1号机',
            state: '1',
            coldOrHot: '100kwh',
            load: '30%'
          }
        ],
        alarmData: [
          {
            grade: '0',
            deviceName: '5号机',
            alarmInfo: '负载超过80%'
          }
        ]
      }
    },
    created() {

    },
    mounted() {
      this.setRefrigeration()
      this.setHeating()
      this.setPowerConsumption()
      this.setTemperature()
      this.setPressure()
      this.setFlow()
    },
    methods: {
      /**
       * 制冷
       */
      setRefrigeration() {
        var refrigerationChart = this.$echarts.init(document.getElementById('refrigeration_id'), 'dark')
        var option = {
          series: [
            this.Utils.getEchertsParameConfig(10, '').inside,
            this.Utils.getEchertsParameConfig(10, '').outside
          ]
        };
        refrigerationChart.setOption(option)
      },
      /**
       * 制热
       */
      setHeating() {
        var refrigerationChart = this.$echarts.init(document.getElementById('heating_id'), 'dark')
        var option = {
          series: [
            this.Utils.getEchertsParameConfig(8, '').inside,
            this.Utils.getEchertsParameConfig(8, '').outside
          ]
        };
        refrigerationChart.setOption(option)
      },
      /**
       * 耗电量
       */
      setPowerConsumption() {
        var refrigerationChart = this.$echarts.init(document.getElementById('power_consumption_id'), 'dark')
        var option = {
          series: [
            this.Utils.getEchertsParameConfig(12, 'KW').inside,
            this.Utils.getEchertsParameConfig(12, 'KW').outside
          ]
        };
        refrigerationChart.setOption(option)
      },
      /**
       * 温度
       */
      setTemperature() {
        var refrigerationChart = this.$echarts.init(document.getElementById('temperature_id'), 'dark')
        var option = {
          series: [
            this.Utils.getEchertsParameConfig(28, '°C').inside,
            this.Utils.getEchertsParameConfig(28, '°C').outside
          ]
        };
        refrigerationChart.setOption(option)
      },
      /**
       * 压力
       */
      setPressure() {
        var refrigerationChart = this.$echarts.init(document.getElementById('pressure_id'), 'dark')
        var option = {
          series: [
            this.Utils.getEchertsParameConfig(7, 'kPa').inside,
            this.Utils.getEchertsParameConfig(7, 'kPa').outside
          ]
        };
        refrigerationChart.setOption(option)
      },
      /**
       * 流量
       */
      setFlow() {
        var refrigerationChart = this.$echarts.init(document.getElementById('flow_id'), 'dark')
        var option = {
          series: [
            this.Utils.getEchertsParameConfig(46, 'GB').inside,
            this.Utils.getEchertsParameConfig(46, 'GB').outside
          ]
        };
        refrigerationChart.setOption(option)
      }
    }
  }
</script>

<style scoped>
  .alarm-box {
    padding: 10px;
    height: calc(100% - 50px);
    min-height: calc(100vh - 150px);
  }

  .item-box {
    padding: 0 10px 0 10px;
  }

  .user-avator {
    display: flex;
    justify-content: start;
  }

  .header-item {
    height: 180px;
    /*display: flex;*/
    margin-top: 10px;
    width: 16.6%;
  }

  .header-item-echarts {
    width: 90%;
    height: 90%;
    padding: 0 10px 0 10px;
  }

  .echarts-title {
    margin-top: -7px;
    text-align: center;
  }

  .item-box {
    padding: 0 10px 0 10px;
  }

  .hrader-text {
    text-align: center;
    font-size: 16px;
    font-weight: bold;
  }
</style>
