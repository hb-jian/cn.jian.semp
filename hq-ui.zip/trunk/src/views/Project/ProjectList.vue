<template>
  <div class="pro-box">
    <div style="height: 52px">
      <el-button type="primary" size="small" @click="openCreate">{{ createText }}</el-button>
    </div>
    <div class="project-box">
      <div class="tree-box">
        <el-tree
          :data="treeData"
          :props="defaultProps"
          accordion
          highlight-current
          :expand-on-click-node="false"
          @node-click="handleNodeClick">
        </el-tree>
      </div>
      <div class="list-box">
        <project-table-list
          v-show="isShowProjectList"
          v-on:projectDataInfo="getProjectDataInfo"
          :projectTableData="projectTableData"
          :projectTotalCount="projectTotalCount">
        </project-table-list>
        <device-table-list
          v-show="!isShowProjectList"
          v-on:deviceInfo="getDeviceInfo"
          :deviceTableData="deviceTableData"
          :deviceTotalCount="deviceTotalCount"
          @getDeviceList="getDeviceList">
        </device-table-list>
      </div>
    </div>
    <ui-create-project
      :visibleType="isShowUiCreateProject"
      :dataInfo="projectInfo"
      :isEdit="isProjectEdit"
      @getVisibleType="getProjectVisibleType">
    </ui-create-project>
    <ui-create-device
      :visibleType="isShowUiCreateDevice"
      :dataInfo="deviceInfo"
      :projectId="projectId"
      :isEdit="isDeviceEdit"
      @getDeviceVisibleType="getDeviceVisibleType">
    </ui-create-device>
  </div>
</template>

<script>
  import api from '@/api/'
  import uiCreateDevice from './uiModal/uiCreateDevice'
  import uiCreateProject from './uiModal/uiCreateProject'
  import DeviceTableList from './DeviceTableList'
  import ProjectTableList from './ProjectTableList'

  export default {
    name: 'OrgList',
    components: {
      DeviceTableList,
      ProjectTableList,
      uiCreateProject,
      uiCreateDevice
    },
    data() {
      return {
        tableData: [],
        isShowUiCreateProject: false, // 是否显示创建项目
        projectInfo: {}, // 编辑时 使用数据
        isProjectEdit: false, // 是否编辑项目

        isShowUiCreateDevice: false, // 是否显示创建设备
        deviceInfo: {},
        isDeviceEdit: false,

        createText: '新增项目',
        isCreateProject: true,
        isShowProjectList: true,
        currentPage: 1,
        pageSize: 20,
        projectId: '',   //项目编号ID
        projectTotalCount: 0,
        deviceTotalCount: 0,
        deviceTableData: [],
        projectTableData: [],
        treeData: [
          {
            label: '项目列表',
            id: 1,
            children: []
          }
        ],
        defaultProps: {
          children: 'children',
          label: 'label'
        }
      }
    },
    created() {
      // 获取项目列表
      this.getProjectTreeList()
      this.getProjectList(this.currentPage, this.pageSize);
    },
    methods: {
      /**
       * @param val 接收项目详细信息
       */
      getProjectDataInfo(val, bool) {
        this.projectInfo = val;
        this.isProjectEdit = true;
        this.isShowUiCreateProject = bool;
      },
      /**
       * @param val 接收设备详细信息
       */
      getDeviceInfo(val, bool) {
        this.deviceInfo = val;
        this.isDeviceEdit = true;
        this.isShowUiCreateDevice = bool;
      },
      /**
       * 获取子组件传来的值
       */
      getProjectVisibleType(obj) {
        this.isShowUiCreateProject = obj.type
        if (obj.isGetList) {
          this.getProjectTreeList();
        }
      },
      /**
       * 获取子组件传来的值
       */
      getDeviceVisibleType(val) {
        this.isShowUiCreateDevice = val.type;
        if (val.isGetList) {
          let model = {
            currentPageNube: 1,
            pageSize: 20
          };
          this.getDeviceList(model);
        }
      },
      /**
       * 新增project
       */
      openCreate() {
        if (this.isCreateProject) {
          this.isProjectEdit = false;
          this.isShowUiCreateProject = true
          console.log('新建项目')
        } else {
          this.isDeviceEdit = false;
          this.isShowUiCreateDevice = true
          console.log('新建设备')
        }
      },
      /**
       * 获取项目列表
       */
      getProjectTreeList() {
        var that = this
        var data = {pageIndex: 1, pageSize: 10000}
        this.treeData = [
          {
            label: '项目列表',
            id: 1,
            children: []
          }
        ];
        api.ProjectList(data).then(res => {
          if (res.state.code == 0) {
            this.projectTableData = res.pagingRows.rows
            this.projectTotalCount = res.pagingRows.totalCount
            res.pagingRows.rows.forEach(function (item, idx) {
              that.treeData[0].children.push({
                label: item.name,
                id: item.id
              })
            });
          }
        })
      },
      /**
       *  获取设备列表
       *  @param pageNube 页码
       *  @param pageSize 每页条数
       */
      getProjectList(pageNube, pageSize) {
        var data = {
          pageIndex: pageNube, pageSize: pageSize
        };
        api.ProjectList(data).then(res => {
          if (res.state.code == 0) {
            this.projectTableData = res.pagingRows.rows
            this.projectTotalCount = res.pagingRows.totalCount
            this.$message({
              message: '获取项目列表成功',
              type: 'success'
            });
          }else {
            this.$message({
              message: '获取项目列表失败：' + res.state.message,
              type: 'error'
            });
          }
        })
      },
      /**
       *  获取设备列表
       *  @param devObj
       */
      getDeviceList(devObj) {
        var data = {
          pageIndex: devObj.currentPageNube,
          pageSize: devObj.pageSize,
          projectId: this.projectId
        };
        api.DeviceList(data).then(res => {
          console.log(res)
          if (res.state.code === '0') {
            this.deviceTableData = res.pagingRows.rows
            this.deviceTotalCount = res.pagingRows.totalCount
            this.$message({
              message: '获取设备列表成功',
              type: 'success'
            });
          }else {
            this.$message({
              message: '获取设备列表失败：' + res.state.message,
              type: 'error'
            });
          }
        })
      },

      /**
       * 点击展开
       */
      handleNodeClick(val) {
        console.log(val.id,'===========dian')
        if (val.id == 1) {
          this.isCreateProject = true;
          this.createText = '新增项目';
          this.isShowProjectList = true;
          this.getProjectList(1, 20)
        } else {
          this.isCreateProject = false;
          this.createText = '新增设备';
          this.isShowProjectList = false;
          this.projectId = val.id;
          this.getDeviceList({
            currentPageNube: 1,
            pageSize: 20
          })
        }
      }
    }
  }
</script>

<style scoped>
  .pro-box {
    padding: 15px 15px 0 15px;
    width: calc(100% - 30px);
    height: calc(100% - 60px);
  }

  .project-box {
    width: 100%;
    height: calc(100% - 82px);
    display: flex;
    justify-content: start;
  }

  .pagination-box {
    height: 52px;
    padding: 15px 20px 0 0;
    float: right;
  }

  .tree-box {
    width: 200px;
    height: calc(100% - 5px);
    padding-top: 5px;
    margin-top: -1px;
    background: white;
  }

  .list-box {
    width: calc(100% - 200px);
    padding-top: 0 !important;
    padding-left: 15px;
    height: 100%;
  }
</style>
