<template>
  <el-dialog
    :title="title"
    :visible.sync="dialogVisible"
    :before-close="handleClose">
    <el-tabs v-model="activeName" @tab-click="tabClick">
      <el-tab-pane label="基础信息" name="first">
        <el-form ref="projectModel" :model="projectModel" :rules="prodectRules" label-width="200px">
          <el-form-item label="项目名称：" prop="name" class="item-box">
            <el-input size="small" style="width: 75%" v-model="projectModel.name" placeholder="项目名称"></el-input>
          </el-form-item>
          <el-form-item label="项目投产时间：" prop="timeToMarket">
            <el-date-picker
              v-model="projectModel.timeToMarket"
              type="datetime"
              size="small"
              value-format="yyyy-MM-dd hh:mm:ss"
              placeholder="项目投产时间">
            </el-date-picker>
          </el-form-item>
          <el-form-item label="项目竣工时间："  prop="completionDate">
            <el-date-picker
              v-model="projectModel.completionDate"
              type="datetime"
              size="small"
              value-format="yyyy-MM-dd hh:mm:ss"
              placeholder="选择项目竣工时间">
            </el-date-picker>
          </el-form-item>
          <el-form-item label="建筑性质：" prop="buildingType">
            <el-radio-group v-model="projectModel.buildingType">
              <el-radio label="agriculture">农业</el-radio>
              <el-radio label="hospital">医院</el-radio>
              <el-radio label="common">公建</el-radio>
              <el-radio label="school">学校</el-radio>
            </el-radio-group>
          </el-form-item>
          <el-form-item label="能源类型：" prop="energyType">
            <el-radio-group v-model="projectModel.energyType">
              <el-radio label="mix">复合型</el-radio>
              <el-radio label="groud">地源热泵</el-radio>
              <el-radio label="water">水源热泵</el-radio>
              <el-radio label="boiler">锅炉房</el-radio>
            </el-radio-group>
          </el-form-item>
        </el-form>
      </el-tab-pane>
      <el-tab-pane label="项目配置" name="second">
        <el-form ref="projectModel" :model="projectModel" :rules="prodectRules" label-width="200px">
          <el-form-item label="所属机构名称：" prop="orgName">
            <el-input size="small" style="width: 75%" v-model="projectModel.orgName" @click.native="openSelectEnterprise" readonly placeholder="所属机构名称"></el-input>
          </el-form-item>
          <el-form-item label="装机容量：" prop="capacity">
            <el-input size="small" style="width: 75%" v-model="projectModel.capacity" placeholder="装机容量"></el-input>
          </el-form-item>
          <el-form-item label="覆盖面积：" prop="coverage">
            <el-input size="small" style="width: 75%" v-model="projectModel.coverage" placeholder="覆盖面积"></el-input>
          </el-form-item>
          <el-form-item label="设备配置：" prop="config">
            <el-input size="small" style="width: 75%" v-model="projectModel.config" placeholder="设备配置"></el-input>
          </el-form-item>
        </el-form>
      </el-tab-pane>
      <el-tab-pane label="OPC采集服务器配置" name="third">
        <el-form ref="projectModel" :model="projectModel" :rules="prodectRules" label-width="200px">
          <el-form-item label="OPC采集服务器配置：" prop="opcConfig">
            <el-input size="small" style="width: 75%" v-model="projectModel.opcConfig.host" placeholder="kepServer服务器地址"></el-input>
            <el-input size="small" style="width: 75%" v-model="projectModel.opcConfig.domain" placeholder="kepServer所在域"></el-input>
            <el-input size="small" style="width: 75%" v-model="projectModel.opcConfig.clsid" placeholder="kepServer组件编号"></el-input>
            <el-input size="small" style="width: 75%" v-model="projectModel.opcConfig.user" placeholder="服务器账号"></el-input>
            <el-input size="small" style="width: 75%" v-model="projectModel.opcConfig.pwd" placeholder="服务器密码"></el-input>
          </el-form-item>
        </el-form>
      </el-tab-pane>
      <el-tab-pane label="地理位置" name="fourth">
        <el-form ref="projectModel" :model="projectModel" :rules="prodectRules" label-width="200px">
          <el-form-item label="地理位置：" prop="location">
            <el-input size="small" style="width: 75%" v-model="projectModel.location.address" placeholder="地址"></el-input>
            <el-input size="small" style="width: 75%" v-model="projectModel.location.city" placeholder="城市"></el-input>
            <el-input size="small" style="width: 75%" v-model="projectModel.location.position" placeholder="坐标"></el-input>
          </el-form-item>
        </el-form>
      </el-tab-pane>
    </el-tabs>

    <span slot="footer" class="dialog-footer">
      <el-button @click="cancel" size="small">取 消</el-button>
      <el-button type="primary" size="small" @click="submit">确 定</el-button>
    </span>
    <ui-select-enterprise-item v-if="isShowSelectEnterprise"
                               v-on:closed="closed"
                               :selectedData="selectedData"
                               v-on:confirmSelected="confirmSelected"></ui-select-enterprise-item>
  </el-dialog>
</template>

<script>
  import api from '@/api/'
  import uiSelectEnterpriseItem from '../../../components/uibModal/selectEnterpriseItem'
  export default {
    name: "uiCreateProject",
    props: ['visibleType', 'dataInfo','isEdit'],
    components: {
      uiSelectEnterpriseItem
    },
    data() {
      return {
        dialogVisible: false,
        activeName: 'first',

        isShowSelectEnterprise: false, // 是否显示选择企业
        selectedData: null, //默认选中企业


        title: '新增项目',
        projectModel: {
          name: '',               //项目名称
          buildingType: 'agriculture',       //建筑性质 agriculture 农业, hospital 医院, common 公建 school 学校
          capacity: '',           //装机容量
          timeToMarket: '',       //项目投产时间
          completionDate: '',     //项目竣工时间
          config: '',             //设备配置
          coverage: '',           //覆盖面积
          energyType: 'mix',         //能源类型: mix 复合型, groud 地源热泵, water 水源热泵, boiler 锅炉房
          id: '',                 //项目编号
          location: {
            address: '',          //地址
            city: '',             //所在城市
            position: '',         //位置坐标
          },
          opcConfig: {            //opc 采集服务器配置
            clsid: '',            //kepServer组件编号
            domain: '',           //kepServer所在域
            host: '',             //kepServer服务器地址
            pwd: '',              //服务器密码
            user: '',             //服务器账号
          },
          orgId: '',              //所属机构编号
          orgName: ''             //所属机构名称
        },
        prodectRules: {
          name: [{required: true, message: '请输入账号昵称', trigger: 'blur'}],
          timeToMarket: [{required: true, message: '请选择投产时间', trigger: 'blur'}],
          completionDate: [{required: true, message: '请选择竣工时间', trigger: 'blur'}],
          buildingType: [{required: true, message: '', trigger: 'blur'}],
          energyType: [{required: true, message: '', trigger: 'blur'}],
          orgName: [{required: true, message: '请选择所属机构', trigger: 'blur'}],
          capacity: [{required: true, message: '请设置装机容量', trigger: 'blur'}],
          coverage: [{required: true, message: '请设置覆盖面积', trigger: 'blur'}],
          config: [{required: true, message: '设备配置不能为空', trigger: 'blur'}],
          opcConfig: [{required: true, message: '', trigger: 'blur'}],
          location: [{required: true, message: '', trigger: 'blur'}],
        }
      }
    },
    watch: {
      visibleType(val) {
        this.dialogVisible = val
        if (val) {
          this.initDataInfo()
        }
      },


    },
    created() {

    },
    mounted() {

    },
    methods: {
      /**
       * 初始化数据
       */
      initDataInfo() {
        // 编辑时，model重新赋值
        if (this.isEdit) {
          this.title = '编辑项目'
          this.projectModel = this.dataInfo;
          this.selectedData = {
            name: this.dataInfo.name,
            id: this.dataInfo.id
          }
        }else {
          this.title = '新增项目'
        }
      },
      /**
       * 打开选择企业模态框
       */
      openSelectEnterprise() {
        this.isShowSelectEnterprise = true
      },
      /**
       *  默认数据对象
       */
      defaultDataInfo() {
        return {
          name: '',               //项目名称
            buildingType: 'agriculture',       //建筑性质 agriculture 农业, hospital 医院, common 公建 school 学校
            capacity: '',           //装机容量
            completionDate: '',     //项目竣工时间
            config: '',             //设备配置
            coverage: '',           //覆盖面积
            energyType: 'mix',         //能源类型: mix 复合型, groud 地源热泵, water 水源热泵, boiler 锅炉房
            id: '',                 //项目编号
            location: {
            address: '',          //地址
              city: '',             //所在城市
              position: '',         //位置坐标
          },
          opcConfig: {            //opc 采集服务器配置
            clsid: '',            //kepServer组件编号
              domain: '',           //kepServer所在域
              host: '',             //kepServer服务器地址
              pwd: '',              //服务器密码
              user: '',             //服务器账号
          },
          orgId: '',              //所属机构编号
            orgName: '',            //所属机构名称
            timeToMarket: ''        //项目投产时间
        }
      },
      /**
       *
       * @param done
       */
      tabClick(tab, event) {

      },
      /**
       * 关闭模态框
       * @param done
       */
      handleClose(done) {
        this.$confirm('确认关闭？')
          .then(_r => {
            done();
            this.activeName = 'first'
            this.$emit('getVisibleType', {type: false, isGetList: false})
          })
          .catch(_ => {
          });
      },
      /**
       * 取消
       */
      cancel() {
        this.projectModel = this.defaultDataInfo();
        this.activeName = 'first'
        this.$emit('getVisibleType', {type: false, isGetList: false})
      },
      /**
       * 提交
       */
      submit() {
        if (!this.isEdit) {
          delete this.projectModel.id;
          api.ProjectCreate(this.projectModel).then(res => {
            console.log(res)
            if (res.state.code === '0') {
              this.$message({
                message: '创建项目成功',
                type: 'success'
              });
              // activeName: 'first',
              this.activeName = 'first'
              this.$emit('getVisibleType', {type: false, isGetList: true})
            } else {
              this.$message({
                message: '创建项目失败：' + res.state.message,
                type: 'error'
              });
            }
          })
        } else {
          api.ProjectUpdate(this.projectModel).then(res => {
            console.log(res)
            if (res.state.code === '0') {
              this.$message({
                message: '项目修改成功',
                type: 'success'
              });
              this.activeName = 'first'
              this.$emit('getVisibleType', {type: false, isGetList: true})
            } else {
              this.$message({
                message: '项目修改失败：' + res.state.message,
                type: 'error'
              });
            }
          })
        }
      },
      /**
       * 关闭选择企业模态框
       */
      closed() {
        this.isShowSelectEnterprise = !this.isShowSelectEnterprise;
      },
      /**
       * 提交并关闭选择企业模态框
       * @param data
       */
      confirmSelected(data) {
        this.selectedData = {
          name: data.name,
          id: data.id
        };
        this.projectModel.orgName = data.name
        this.projectModel.orgId = data.id

        console.log(data,'----------->');
        this.isShowSelectEnterprise = !this.isShowSelectEnterprise;
      }
    }
  }
</script>

<style>
  body .el-dialog {
    background: white;
  }
  body .el-form-item {
    margin-bottom: 20px;
  }
  body .el-divider--horizontal {
    display: block;
    height: 1px;
    width: 100%;
    margin: -24px 0 20px 0;
  }

</style>
