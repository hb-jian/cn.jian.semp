<template>
  <div class="modal-backdrop" style="z-index: 10000">
    <div class="modal">
      <div class="modal-header">
        <h3 style="font-weight: bold; font-size: 16px">设置数据项</h3>
      </div>
      <div class="modal-body">
        <div style="margin-left: 25px">
          <el-form ref="dataModel" :model="dataModel" label-width="200px">
            <el-form-item label="数据项名称：" prop="name" class="item-box">
              <el-input size="small" style="width: 75%" v-model="dataModel.name" placeholder="数据项名称"></el-input>
            </el-form-item>
            <el-form-item label="数据项类型：" prop="opcItemTypeEnum" class="item-box">
              <el-input size="small" style="width: 75%" v-model="dataModel.opcItemTypeEnum" placeholder="数据项类型"></el-input>
            </el-form-item>
            <el-form-item label="数据项编号：" prop="kepids" class="item-box">
              <el-input type="textarea" rows="5" size="small" style="width: 75%" v-model="dataModel.kepid" placeholder="一行为一条数据项编号"></el-input>
            </el-form-item>
            <el-form-item label="数据合并规则：" prop="mergeRuleEnum" class="item-box">
              <el-radio-group v-model="dataModel.mergeRuleEnum">
                <el-radio label="Avg">平均</el-radio>
                <el-radio label="Sum">累计</el-radio>
                <el-radio label="Max">最大值</el-radio>
                <el-radio label="Min">最小值</el-radio>
              </el-radio-group>
            </el-form-item>
          </el-form>
        </div>
      </div>
      <div class="modal-footer">
        <el-button size="small" @click="closeSelf">关闭</el-button>
        <el-button size="small" type="primary" @click="confirm">确认</el-button>
      </div>
    </div>
  </div>
</template>

<script>
  export default {
    name: "uiSettingDataItem",
    data() {
      return {
        dataModel: {
          name: '',
          kepid: '',
          kepids: [],
          mergeRuleEnum: 'Avg',
          opcItemTypeEnum: ''
        }
      }
    },
    created() {},
    mounted() {},
    methods: {
      /**
       * 字符串转集合
       */
      getKepidsArr(val) {
        let tempList = val.split(/[(\r\n)\r\n]+/);
        return tempList;
      },
      /**
       * 关闭
       */
      closeSelf() {
        this.$emit("closed");
      },
      /**
       * 提交
       */
      confirm() {
        let model = {
          name: this.dataModel.name,
          kepids: this.getKepidsArr(this.dataModel.kepid),
          mergeRuleEnum: this.dataModel.mergeRuleEnum,
          opcItemTypeEnum: this.dataModel.opcItemTypeEnum
        };
        this.$emit("confirmData", model);
      }
    }
  }
</script>

<style scoped>
  .modal-backdrop {
    position: fixed;
    top: 0;
    right: 0;
    bottom: 0;
    left: 0;
    background-color: rgba(0, 0, 0, .7);
    display: flex;
    justify-content: center;
    align-items: center;
  }

  .modal {
    background-color: #fff;
    box-shadow: 2px 2px 20px 1px;
    overflow-x: auto;
    display: flex;
    flex-direction: column;
    border-radius: 4px;
    width: 700px;
    height: 500px;
  }

  .modal-header {
    border-bottom: 1px solid #eee;
    color: #313131;
    justify-content: space-between;
    padding: 15px;
    display: flex;
  }

  .modal-footer {
    border-top: 1px solid #eee;
    justify-content: flex-end;
    padding: 15px;
    display: flex;
  }

  .modal-body {
    height: 400px;
    position: relative;
    padding: 20px 10px;
  }
</style>
