<template>
  <el-dialog
    :title="title"
    :visible.sync="dialogVisible"
    :before-close="handleDeviceClose">
    <el-divider></el-divider>
    <el-form ref="projectModel" :model="deviceModel" :rules="deviceRules" label-width="200px">
      <el-form-item label="设备名称：" prop="name" class="item-box">
        <el-input size="small" style="width: 75%" v-model="deviceModel.name" placeholder="设备名称"></el-input>
      </el-form-item>
      <el-form-item label="项目编号：" prop="projectId" class="item-box">
        <el-input size="small" style="width: 75%" v-model="deviceModel.projectId" readonly disabled
                  placeholder="项目编号"></el-input>
      </el-form-item>
      <el-form-item label="设置数据项：" prop="dataItems" class="item-box">
        <el-button type="primary" size="mini" icon="el-icon-edit" circle @click="settingData()"></el-button>
      </el-form-item>
      <el-form-item label="数据项列表：" prop="dataItems" class="item-box">
        <div class="tables-Box">
          <el-table
            ref="dataTable"
            :data="deviceModel.dataItems"
            tooltip-effect="dark"
            style="width: 100%"
            height="100%">
            <el-table-column
              type="selection"
              width="55">
            </el-table-column>
            <el-table-column
              prop="name"
              label="数据项名称">
            </el-table-column>
            <el-table-column
              prop="opcItemTypeEnum"
              label="数据类型">
            </el-table-column>
            <el-table-column
              prop="mergeRuleEnum"
              :formatter="setRuleEnum"
              label="数据合并规则">
            </el-table-column>
            <el-table-column
              fixed="right"
              label="操作"
              width="120">
              <template slot-scope="scope">
                <el-button @click="deleteItem(scope.$index)" type="text" size="small"> 删除</el-button>
              </template>
            </el-table-column>
          </el-table>
        </div>
      </el-form-item>
    </el-form>

    <span slot="footer" class="dialog-footer">
      <el-button @click="cancel" size="small">取 消</el-button>
      <el-button type="primary" size="small" @click="submit">确 定</el-button>
    </span>
    <ui-setting-data-item v-if="isShowModal" v-on:closed="closed" :settingDataList="settingDataList"
                          v-on:confirmData="confirmData"></ui-setting-data-item>
  </el-dialog>
</template>

<script>
  import api from '@/api/'
  import uiSettingDataItem from './uiSettingDataItem'

  export default {
    name: "uiCreateDevice",
    props: ['visibleType', 'dataInfo', 'projectId', 'isEdit'],
    components: {
      uiSettingDataItem
    },
    data() {
      return {
        activeName: 'first',
        settingDataList: [],
        isShowModal: false,

        dialogVisible: false,
        title: '新增设备',
        deviceModel: {
          dataItems: [],
          id: '',
          name: '',
          projectId: '',
        },
        deviceRules: {
          name: [{required: true, message: '请输入设备名称', trigger: 'blur'}],
          projectId: [{required: true, message: '项目编号不能为空', trigger: 'blur'}],
          dataItems: [{required: true, message: '', trigger: 'blur'}],
        }
      }
    },
    watch: {
      visibleType(val) {
        this.dialogVisible = val
        if (val) {
          this.initDataInfo()
          this.deviceModel.projectId = this.projectId
        }
      }
    },
    created() {

    },
    mounted() {

    },
    methods: {
      defaultDataInfo() {
        return {
          dataItems: [],
          id: '',
          name: '',
          projectId: '',
        }
      },

      /**
       * 合并规则文本转换
       */
      setRuleEnum(val) {
        if (val.mergeRuleEnum === 'Avg') {
          return '平均'
        } else if (val.mergeRuleEnum === 'Sum') {
          return '累计'
        } else if (val.mergeRuleEnum === 'Max') {
          return '最大值'
        } else if (val.mergeRuleEnum === 'Min') {
          return '最小值'
        }
      },

      /**
       * 初始化数据
       */
      initDataInfo() {
        if (this.isEdit) {
          this.title = '编辑设备'
          this.deviceModel = this.dataInfo
        } else {
          this.title = '新增设备'
        }
      },

      handleDeviceClose(done) {
        this.$confirm('确认关闭？')
          .then(_r => {
            done();
            this.activeName = 'first'
            this.$emit('getDeviceVisibleType', {type: false, isGetList: false})
          })
          .catch(_ => {
          });
      },
      /**
       * 删除数据项列表某条
       */
      deleteItem(index) {
        let dataArr = [];
        this.deviceModel.dataItems.forEach((item, idx) => {
          if (index != idx) {
            dataArr.push(item)
          }
        });
        this.deviceModel.dataItems = dataArr;
      },
      settingData() {
        this.isShowModal = !this.isShowModal;
      },
      /**
       *  关闭设置数据项模态框
       */
      closed() {
        this.isShowModal = !this.isShowModal;
      },
      /**
       *  设置数据项模态框 提交
       */
      confirmData(val) {
        this.deviceModel.dataItems.push(val);
        this.isShowModal = !this.isShowModal;
      },
      /**
       * 取消
       */
      cancel() {
        this.deviceModel = this.defaultDataInfo();
        this.activeName = 'first'
        this.$emit('getDeviceVisibleType', {type: false, isGetList: false})
      },
      /**
       * 提交
       */
      submit() {
        if (!this.isEdit) {
          delete this.deviceModel.id
          api.DeviceCreate(this.deviceModel).then(res => {
            if (res.state.code === '0') {
              this.activeName = 'first'
              this.$emit('getDeviceVisibleType', {type: false, isGetList: true})
              this.$message({
                message: '新建设备成功',
                type: 'success'
              });
            } else {
              this.$message({
                message: '新建设备失败：' + res.state.message,
                type: 'error'
              });
            }
          })
        } else {
          api.DeviceUpdate(this.deviceModel).then(res => {
            if (res.state.code === '0') {
              this.activeName = 'first'
              this.$emit('getDeviceVisibleType', {type: false, isGetList: true})
              this.$message({
                message: '新建设备成功',
                type: 'success'
              });
            } else {
              this.$message({
                message: '新建设备失败：' + res.state.message,
                type: 'error'
              });
            }
          })
        }
      }
    }
  }
</script>

<style>
  body .el-dialog {
    background: white;
  }

  body .el-form-item {
    margin-bottom: 20px;
  }

  body .el-divider--horizontal {
    display: block;
    height: 1px;
    width: 100%;
    margin: -24px 0 20px 0;
  }

  .tables-Box {
    height: 300px;
    margin-right: 120px;
    border: solid 1px #cccccc;
    margin-top: 12px;
  }

</style>
