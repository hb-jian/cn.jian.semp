<template>
  <div class="device-box">
    <el-table
      ref="multipleTable"
      :data="tableData"
      tooltip-effect="dark"
      style="width: 100%"
      height="100%"
      @selection-change="handleSelectionChange">
      <el-table-column
        type="selection"
        width="55">
      </el-table-column>
      <el-table-column
        label="名称">
        <template slot-scope="scope">{{ scope.row.name }}</template>
      </el-table-column>
      <el-table-column
        prop="capacity"
        label="装机容量">
      </el-table-column>
      <el-table-column
        prop="config"
        label="配置"
        show-overflow-tooltip>
      </el-table-column>
      <el-table-column
        prop="completionDate"
        label="竣工时间">
      </el-table-column>
      <!--<el-table-column-->
      <!--prop="name"-->
      <!--label="累计能耗">-->
      <!--</el-table-column>-->
      <!--<el-table-column-->
      <!--prop="name"-->
      <!--label="数据大屏">-->
      <!--</el-table-column>-->
      <el-table-column
        fixed="right"
        label="操作"
        width="120">
        <template slot-scope="scope">
          <el-button type="text" size="small" @click="modifyRow(scope.row)">编辑</el-button>
        </template>
      </el-table-column>
    </el-table>
    <div class="pagination-box">
      <el-pagination
        background
        @size-change="handleSizeChange"
        @current-change="handleCurrentChange"
        :current-page="currentPageNube"
        :page-sizes="[20, 50, 100]"
        :page-size="20"
        layout="total, sizes, prev, pager, next, jumper"
        :total="projectTotalCount">
      </el-pagination>
    </div>
  </div>
</template>

<script>
  import api from '@/api/'

  export default {
    name: "ProjectTableList",
    props: ['projectTableData', 'projectTotalCount'],
    data() {
      return {
        tableData: this.projectTableData,
        projectId: '',
        currentPageNube: 1, // 当前页码
        pageSize: 20,   // 默认每页条数
        totalCount: this.projectTotalCount,  // 默认显示总数量
      }
    },
    created() {
    },
    watch: {
      projectTableData: function (val) {
        this.tableData = val
      },
      projectTotalCount: function (val) {
        this.totalCount = val
      }
    },
    methods: {
      handleSelectionChange(val) {
        console.log(`选中 ${val} 条`);
      },
      handleSizeChange(val) {
        console.log(`每页 ${val} 条`);
        this.pageSize = val
      },
      handleCurrentChange(val) {
        console.log(`当前页: ${val}`);
        this.pageSize = val
      },
      /**
       * 编辑
       * @param index
       * @param val
       */
      modifyRow(val) {
        let model = {id: val.id}
        api.ProjectGet(model).then(res => {
          console.log(res)
          if (res.state.code === '0') {
            this.$emit("projectDataInfo", res.data, true);
          }else {
            this.$message({
              message: '获取详情失败' + res.state.message,
              type: 'error'
            });
          }
        })
      }
    }
  }
</script>

<style scoped>
  .device-box {
    height: 100%;
  }

  .pagination-box {
    height: 52px;
    padding: 15px 20px 0 0;
    float: right;
  }
</style>
