<template>
  <div class="warp-box">
    <div class="el-row" style="margin: 0 -10px 0 -10px">
      <!--首页头部-->
      <div class="el-col el-col-24 el-col-xs-24 item-box">
        <div class="el-card box-card is-always-shadow">
          <div class="el-card__body">
            <div>
              <div class="text-center">
                <div class="greet-word-box">
                  <span>{{ greetWord }}</span>
                  欢迎：
                  <span>{{ accountName }}</span>
                </div>
                <div class="user-avator">
                  <div style="display: flex; margin-top: 10px">
                    <img src="../assets/img/img.jpg"/>
                    <div style="height: 80px;margin-left: 20px">
                      <div style="font-size: 14px; font-weight: bold;margin-top: 15px;">
                        用户账号：{{ accountName }}
                      </div>
                      <div style="font-size: 14px; font-weight: bold; margin-top: 25px">
                        最近登录时间：2022-02-14 14:37:41
                      </div>
                    </div>
                  </div>
                  <div style="width: 50%; margin-top: 10px">
                    <div style="font-size: 14px; font-weight: bold;margin-top: 15px">
                      <span>
                        所属企业：华清荣
                      </span>
                    </div>
                    <div style="font-size: 14px; font-weight: bold;margin-top: 25px">
                      <span>
                        企业大屏：
                        <el-link type="primary" href="https://share.shanhaibi.com/620a076dcedf1/"
                                 style="font-size: 16px"
                                 target="_blank">https://share.shanhaibi.com/620a076dcedf1/</el-link>
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <!--待办事项-->
      <div class="el-col el-col-12 el-col-xs-24 item-box" style="padding-bottom: 10px">
        <div class="el-card box-card is-always-shadow" style="height: 400px; margin-top: 15px;">
          <div class="el-card__header hrader-text">
            <div class="clearfix">
              <span>待办事项</span>
            </div>
          </div>
          <div class="el-card__body" style="height: 320px; overflow: auto;">
            <el-timeline :reverse="reverse">
              <el-timeline-item
                v-for="(activity, index) in activities"
                :key="index"
                :timestamp="activity.timestamp">
                {{activity.content}}
              </el-timeline-item>
            </el-timeline>
          </div>
        </div>
      </div>
      <!--系统通知-->
      <div class="el-col el-col-12 el-col-xs-24 item-box" style="padding-bottom: 10px">
        <div class="el-card box-card is-always-shadow" style="height: 400px; margin-top: 15px;">
          <div class="el-card__header hrader-text">
            <div class="clearfix">
              <span>系统通知</span>
            </div>
          </div>
          <div class="el-card__body" style="height: 320px; overflow: auto">
            <el-table
              :data="noticeData"
              :header-cell-style="{background: '#dddddd',color: '#000000'}"
              border
              style="width: 100%">
              <el-table-column
                prop="date"
                label="时间"
                width="180">
              </el-table-column>
              <el-table-column
                prop="name"
                label="类型"
                width="180">
              </el-table-column>
              <el-table-column
                prop="address"
                label="通知内容">
              </el-table-column>
            </el-table>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
  import gitImg from '@/assets/img/zan.jpg'

  export default {
    data: function () {
      return {
        buttonHtml: '<v-button></v-button>',
        gitImg,
        greetWord: '',
        accountName: '',
        reverse: false,
        activities: [{
          content: '待办项',
          timestamp: '2018-04-15'
        }, {
          content: '待办项',
          timestamp: '2018-04-13'
        }, {
          content: '待办项',
          timestamp: '2018-04-11'
        }, {
          content: '待办项',
          timestamp: '2018-04-13'
        }, {
          content: '待办项',
          timestamp: '2018-04-11'
        }, {
          content: '待办项',
          timestamp: '2018-04-13'
        }, {
          content: '待办项',
          timestamp: '2018-04-11'
        }],
        noticeData: [{
          date: '2016-05-02',
          name: '通知消息',
          address: '设备巡检通知'
        }, {
          date: '2016-05-04',
          name: '消息告警',
          address: '消息阻塞通知'
        }, {
          date: '2016-05-01',
          name: '统计告警',
          address: '统计告警'
        }, {
          date: '2016-05-03',
          name: '通知消息',
          address: '消息通知'
        }, {
          date: '2016-05-04',
          name: '消息告警',
          address: '设备巡检通知'
        }, {
          date: '2016-05-01',
          name: '统计告警',
          address: '设备统计巡检通知'
        }, {
          date: '2016-05-03',
          name: '通知消息',
          address: '设备巡检通知'
        }, {
          date: '2016-05-04',
          name: '消息告警',
          address: '设备巡检通知'
        }, {
          date: '2016-05-01',
          name: '统计告警',
          address: '设备巡检通知'
        }, {
          date: '2016-05-03',
          name: '通知消息',
          address: '设备巡检通知'
        }]
      }
    },
    created() {
      this.greetWord = this.Utils.getGreetWord()
      this.accountName = this.Utils.getUserData().name
    }
  }
</script>

<style scoped>
  .warp-box {
    padding: 10px;
    height: calc(100% - 50px);
    min-height: calc(100vh - 150px);
  }

  .item-box {
    padding: 0 10px 0 10px;
  }

  .text-center {
    text-align: left;
  }

  .greet-word-box {
    font-size: 18px;
    font-weight: bold;
    padding-bottom: 10px;
  }

  .list-group {
    padding-left: 0;
    list-style: none;
  }

  .list-group-striped .list-group-item {
    border-left: 0;
    border-right: 0;
    border-radius: 0;
    padding-left: 0;
    padding-right: 0;
  }

  .list-group-item {
    border-bottom: 1px solid #e7eaec;
    border-top: 1px solid #e7eaec;
    margin-bottom: -1px;
    padding: 11px 0;
    font-size: 13px;
  }

  .pull-right {
    float: right !important;
  }

  .user-avator {
    display: flex;
    justify-content: space-between;
  }

  .user-avator img {
    width: 80px;
    height: 80px;
    border-radius: 10%;
  }

  .hrader-text {
    text-align: center;
    font-size: 16px;
    font-weight: bold;
  }
</style>
