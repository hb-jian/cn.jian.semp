<template>
  <div class="list-box">
    <div style="height: 52px">
      <el-button type="primary" size="small" @click="openCreateRole">创建角色</el-button>
    </div>
    <ui-create-role
      :visibleType="dialogVisible"
      :dataInfo="dataInfo"
      :isEdit="isEdit"
      @getRoleVisibleType="getRoleVisibleType">
    </ui-create-role>
    <el-table
      ref="multipleTable"
      :data="tableData"
      tooltip-effect="dark"
      style="width: 100%"
      height="calc(100% - 52px)"
      @selection-change="handleSelectionChange">
      <el-table-column
        type="selection"
        width="55">
      </el-table-column>
      <el-table-column
        prop="name"
        label="名称">
      </el-table-column>
      <el-table-column
        fixed="right"
        label="操作"
        width="120">
        <template slot-scope="scope">
          <el-button type="text" size="small" @click="modifyRow(scope.row)">编辑</el-button>
        </template>
      </el-table-column>
    </el-table>
    <div class="pagination-box">
      <el-pagination
        background
        @size-change="handleSizeChange"
        @current-change="handleCurrentChange"
        :current-page="currentPage"
        :page-sizes="[20, 50, 100]"
        :page-size="pageSize"
        layout="total, sizes, prev, pager, next, jumper"
        :total="totalCount">
      </el-pagination>
    </div>
  </div>
</template>

<script>
  import api from '@/api/'
  import uiCreateRole from './uiModel/uiCreateRole'
  export default {
    name: 'UserRole',
    components: {
      uiCreateRole
    },
    data() {
      return {
        dialogVisible: false,
        isEdit: false,
        dataInfo: {
          name: '',         //角色名称
          orgId: '',        //所属机构ID
          orgName: '',      //所属机构
          roleType: '',     //角色类型
          menus: [],        // 菜单
        },

        tableData: [],
        totalCount: 0,
        currentPage: 1,
        pageSize: 20
      }
    },
    created() {
      this.initPage(this.currentPage,this.pageSize)
    },
    mounted() {},
    methods: {
      /**
       * 初始化列表数据
       */
      initPage(pageNum,pageSize) {
        let model = {pageIndex: pageNum, pageCount: pageSize}
        api.getRoleList(model).then( res => {
          if (res.state.code == 0) {
            this.totalCount = res.pagingRows.totalCount
            this.tableData = res.pagingRows.rows
            this.$message({
              message: '获取角色列表成功',
              type: 'success'
            });
          } else {
            this.$message({
              message: '获取角色列表失败：' + res.state.message,
              type: 'error'
            });
          }
        })
      },
      /**
       * 创建角色
       */
      openCreateRole() {
        this.isEdit = false;
        this.dialogVisible = true;
      },
      getRoleVisibleType(val) {
        console.log(val,'=====>')
        this.dialogVisible = val.type
        if (val.isGetList) {
          this.initPage(1, this.pageSize);
        }
      },

      /**
       * 操作
       * @param val
       */
      modifyRow(val) {
        console.log(val,'=====')
        let model = {id: val.id}
        api.RoleGet(model).then(res => {
          console.log(res)
          if (res.state.code === '0') {
            this.dataInfo = res.data
          }else {
            this.$message({
              message: '获取详情失败' + res.state.message,
              type: 'error'
            });
          }
        })
      },

      handleSelectionChange(val) {
        console.log(`每页 ${val} 条`);
      },
      handleSizeChange(val) {
        console.log(`每页 ${val} 条`);
      },
      handleCurrentChange(val) {
        console.log(`当前页: ${val}`);
      }
    }
  }
</script>

<style scoped>
  .list-box {
    padding: 15px 15px 0 15px;
    width: calc(100% - 30px);
    height: calc(100% - 82px);
  }
  .pagination-box {
    height: 52px;
    padding: 15px 20px 0 0;
    float: right;
  }

  body .el-dialog {
    background: white;
  }
</style>
