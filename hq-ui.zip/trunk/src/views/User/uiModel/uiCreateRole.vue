<template>
  <el-dialog
    :title="title"
    :visible.sync="dialogVisible"
    :before-close="handleClose">
    <el-divider></el-divider>
    <el-form ref="roleModel" :model="roleModel" :rules="roleRules" label-width="120px">
      <el-form-item label="角色名称：" prop="name">
        <el-input size="small" style="width: 75%" v-model="roleModel.name"></el-input>
      </el-form-item>
      <el-form-item label="角色类型：" prop="roleType">
        <el-radio-group v-model="roleModel.roleType">
          <el-radio label="system">系统</el-radio>
          <el-radio label="org">企业</el-radio>
        </el-radio-group>
      </el-form-item>
      <el-form-item label="所属机构：" prop="orgName" v-if="roleModel.roleType !== 'system'">
        <el-input size="small" style="width: 75%" v-model="roleModel.orgName" @click.native="openSelectEnterprise"
                  readonly placeholder="所属机构名称"></el-input>
      </el-form-item>
      <el-form-item label="企业菜单：" prop="menus">
        <el-button type="primary" icon="el-icon-menu" size="small" circle @click="selectMenu"></el-button>
      </el-form-item>
    </el-form>
    <span slot="footer" class="dialog-footer">
        <el-button @click="cancel" size="small">取 消</el-button>
        <el-button type="primary" size="small" @click="submit">确 定</el-button>
      </span>
    <uib-modal v-if="showModal" v-on:closeme="closeme" :selectedData="selectedData"
               v-on:confirmSelected="confirmSelected"></uib-modal>

    <ui-select-enterprise-item v-if="isShowSelectEnterprise"
                               v-on:closed="closed"
                               :selectedData="selectedEnterpriseData"
                               v-on:confirmSelected="submitSelected"></ui-select-enterprise-item>
  </el-dialog>
</template>

<script>
  import api from '@/api/'
  import uibModal from '../../../components/uibModal/selectMenuModal'
  import uiSelectEnterpriseItem from '../../../components/uibModal/selectEnterpriseItem'

  export default {
    name: "uiCreateRole",
    props: ['visibleType', 'dataInfo', 'isEdit'],
    components: {
      uibModal,
      uiSelectEnterpriseItem
    },
    data() {
      return {
        isShowSelectEnterprise: false,
        selectedEnterpriseData: [],

        showModal: false,
        selectedData: [],

        title: '新建角色',
        dialogVisible: false,

        roleModel: {
          name: '',         //角色名称
          id: '',           //角色ID 创建时不需要
          orgId: '',        //所属机构ID
          orgName: '',      //所属机构
          roleType: 'system',     //角色类型
          menus: [],        // 菜单
        },
        roleRules: {
          name: [{required: true, message: '请输入角色名称', trigger: 'blur'}],
          roleType: [{required: true, message: '请选择角色类型', trigger: 'blur'}],
          orgName: [{required: true, message: '请选择所属机构', trigger: 'blur'}],
          menus: [{required: true, message: '', trigger: 'blur'}],
        }
      }
    },
    watch: {
      visibleType(val) {
        this.dialogVisible = val
        if (val) {
          // this.initDataInfo()
        }
      }
    },
    created() {
    },
    mounted() {
    },
    methods: {
      handleClose(done) {
        this.$confirm('确认关闭？')
          .then(_r => {
            done();
            this.$emit('getRoleVisibleType', {type: false, isGetList: false})
          })
          .catch(_ => {
          });
      },
      defaultDataInfo() {
        return {
          name: '',                //角色名称
          orgId: '',               //所属机构ID
          id: '',                  //角色ID 创建时不需要
          roleType: 'system',      //角色类型
          menus: [],               // 菜单
        }
      },
      cancel() {
        this.roleModel = this.defaultDataInfo();
        this.$emit('getRoleVisibleType', {type: false, isGetList: false})
      },
      submit() {
        console.log(this.roleModel)
        delete this.roleModel.id;
        delete this.roleModel.orgName
        if (this.roleModel.roleType !== 'system') {
          delete this.roleModel.orgId
        }
        api.RoleCreate(this.roleModel).then(res => {
          console.log(res)
          if (res.state.code === '0') {
            this.$message({
              message: '创建角色成功',
              type: 'success'
            });
            this.$emit('getRoleVisibleType', {type: false, isGetList: true})
          } else {
            this.$message({
              message: '创建角色失败：' + res.state.message,
              type: 'error'
            });
          }
        })
      },

      /**
       * 打开选择企业模态框
       */
      openSelectEnterprise() {
        this.isShowSelectEnterprise = true
      },
      /**
       * 菜单选择事件
       */
      selectMenu() {
        this.showModal = !this.showModal;
      },

      /**
       * 关闭选择企业模态框
       */
      closed() {
        this.isShowSelectEnterprise = !this.isShowSelectEnterprise;
      },
      /**
       * 提交选择企业模态框
       */
      submitSelected(data) {
        this.selectedEnterpriseData = {
          name: data.name,
          id: data.id
        };
        this.roleModel.orgName = data.name
        this.roleModel.orgId = data.id

        console.log(data, '----------->');
        this.isShowSelectEnterprise = !this.isShowSelectEnterprise;
      },

      /**
       * 提交 关闭模态框 并返回携带的值
       */
      confirmSelected(data, halfData) {
        this.selectedData = data;
        let selectedArr = [];
        if (data.length > 0) {
          data.forEach(item => {
            selectedArr.push({
              id: item,
              halfChecked: false
            })
          })
        }
        if (halfData.length > 0) {
          halfData.forEach(item => {
            selectedArr.push({
              id: item,
              halfChecked: true
            })
          })
        }
        this.roleModel.menus = selectedArr;
        console.log(this.roleModel.menus, '====menus====');
        this.showModal = !this.showModal;
      },
      /**
       *  关闭模态框
       */
      closeme() {
        this.showModal = !this.showModal;
      },
    }
  }
</script>

<style>
  body .el-dialog {
    background: white;
  }

  body .el-form-item {
    margin-bottom: 20px;
  }

  body .el-divider--horizontal {
    display: block;
    height: 1px;
    width: 100%;
    margin: -24px 0 20px 0;
  }

  .tables-Box {
    height: 300px;
    margin-right: 120px;
    border: solid 1px #cccccc;
    margin-top: 12px;
  }
</style>
