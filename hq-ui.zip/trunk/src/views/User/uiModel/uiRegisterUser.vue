<template>
  <el-dialog
    :title="title"
    :visible.sync="dialogVisible"
    :before-close="handleClose">
    <el-divider></el-divider>

    <el-form ref="userModel" :model="userModel" :rules="userRules" label-width="120px">
      <el-form-item label="账号：" prop="account" v-if="!isEdit">
        <el-input size="small" style="width: 75%" v-model="userModel.account"></el-input>
      </el-form-item>
      <el-form-item label="密码：" prop="pwd" v-if="!isEdit">
        <el-input size="small" style="width: 75%" v-model="userModel.pwd"></el-input>
      </el-form-item>
      <el-form-item label="昵称：" prop="name">
        <el-input size="small" style="width: 75%" v-model="userModel.name"></el-input>
      </el-form-item>
      <el-form-item label="角色名称：" prop="roleName">
        <el-input size="small" style="width: 75%" v-model="userModel.roleName" @click.native="openSelectRole" readonly placeholder="所属角色"></el-input>
      </el-form-item>
      <el-form-item label="所属企业：" prop="orgName">
        <el-input size="small" style="width: 75%" v-model="userModel.orgName" @click.native="openSelectEnterprise" readonly placeholder="所属机构名称"></el-input>
      </el-form-item>
    </el-form>
    <span slot="footer" class="dialog-footer">
        <el-button @click="cancel" size="small">取 消</el-button>
        <el-button type="primary" size="small" @click="submit">确 定</el-button>
      </span>
    <ui-select-enterprise-item v-if="isShowSelectEnterprise"
                               v-on:closed="closed"
                               :selectedData="selectedData"
                               v-on:confirmSelected="confirmSelected"></ui-select-enterprise-item>

    <ui-select-role-item v-if="isShowSelectRole"
                         v-on:closed="closedRoleMadel"
                         :selectedData="selectedRoleData"
                         v-on:confirmSelected="confirmSelectedRoleMadel">
    </ui-select-role-item>
  </el-dialog>
</template>

<script>
  import uiSelectEnterpriseItem from '../../../components/uibModal/selectEnterpriseItem'
  import uiSelectRoleItem from '../../../components/uibModal/selectRoleItem'
  import api from '@/api/'
  export default {
    name: "uiRegisterUser",
    props: ['visibleType', 'dataInfo', 'isEdit'],
    components: {
      uiSelectEnterpriseItem,uiSelectRoleItem
    },
    data() {
      return {
        title: '注册用户',
        dialogVisible: false,

        isShowSelectEnterprise: false,
        selectedData: null, //默认选中企业

        isShowSelectRole: false,
        selectedRoleData: null,


        userModel: {
          account: '',    //账号
          name: '',       //昵称
          pwd: '',        //密码
          orgId: '',      //企业ID
          orgName: '',      //企业ID
          roleId: '',      //角色ID
          roleName: ''      //角色ID
        },
        userRules: {
          account: [{required: true, message: '请输入账号', trigger: 'blur'}],
          pwd: [{required: true, message: '请输入密码', trigger: 'blur'}],
          name: [{required: true, message: '请输入昵称', trigger: 'blur'}],
          roleName: [{required: true, message: '请选择角色', trigger: 'blur'}],
          orgName: [{required: true, message: '请选择所属企业', trigger: 'blur'}],
        }
      }
    },
    watch: {
      visibleType(val) {
        this.dialogVisible = val
        // if (val) {
        //   this.initDataInfo()
        // }
      },
      dataInfo(newval, oldval) {
        console.log(newval, oldval)
      }
    },
    created() {},
    mounted() {},
    methods: {
      defaultUserModel() {
        return {
          account: '',    //账号
          name: '',       //昵称
          pwd: '',        //密码
          orgId: '',      //企业ID
          orgName: '',      //企业ID
          roleId: '',      //角色ID
          roleName: ''      //角色ID
        }
      },
      /**
       * 确认关闭提示框
       */
      handleClose() {
        this.$confirm('确认关闭？')
          .then(_r => {
            done();
            this.$emit('getVisibleType', {type: false, isGetList: false})
          })
          .catch(_ => {
          });
      },
      openSelectRole() {
        this.isShowSelectRole = true
      },
      openSelectEnterprise() {
        this.isShowSelectEnterprise = true
      },
      closedRoleMadel() {
        this.isShowSelectRole = !this.isShowSelectRole
      },
      confirmSelectedRoleMadel(data) {
        console.log(data,'====')
        this.selectedRoleData = {
          name: data.name,
          id: data.id
        };
        this.userModel.roleName = data.name
        this.userModel.roleId = data.id

        this.isShowSelectRole = !this.isShowSelectRole;
      },
      /**
       * 关闭选择企业模态框
       */
      closed() {
        this.isShowSelectEnterprise = !this.isShowSelectEnterprise;
      },
      /**
       * 提交并关闭选择企业模态框
       * @param data
       */
      confirmSelected(data) {
        this.selectedData = {
          name: data.name,
          id: data.id
        };
        this.userModel.orgName = data.name
        this.userModel.orgId = data.id

        console.log(data,'----------->');
        this.isShowSelectEnterprise = !this.isShowSelectEnterprise;
      },
      /**
       * 取消
       */
      cancel() {
        this.userModel = this.defaultUserModel()
        this.selectedData = null;
        this.$emit('getVisibleType', {type: false, isGetList: false})
      },
      /**
       * 提交
       */
      submit() {
        delete this.userModel.orgName
        delete this.userModel.roleName
        console.log(this.userModel)
        api.Regist(this.userModel).then(res => {
          if (res.state.code === '0') {
            this.$emit('getVisibleType', {type: false, isGetList: true})
            this.$message({
              message: '注册成功',
              type: 'success'
            });
          } else {
            this.$message({
              message: '接口调用失败，' + res.state.message,
              type: 'error'
            });
          }
        })
      }
    }
  }
</script>

<style>

</style>
