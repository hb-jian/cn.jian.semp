<template>
  <div class="warp-box">
    <div class="el-row" style="margin: 0 -10px 0 -10px">
      <!--个人信息-->
      <div class="el-col el-col-6 el-col-xs-24 item-box">
        <div class="el-card box-card is-always-shadow" style="padding-bottom: 22px;">
           <div class="el-card__header">
             <div class="clearfix">
               <span>个人信息</span>
             </div>
           </div>
           <div class="el-card__body">
             <div>
                <div class="text-center">
                  <div class="user-avator">
                    <img src="../assets/img/img.jpg"/>
                  </div>
                </div>
               <ul class="list-group list-group-striped">
                 <li class="list-group-item">
                   用户名：
                   <div class="pull-right">admin</div>
                 </li>
                 <li class="list-group-item">
                   手机号：
                   <div class="pull-right">13131113131</div>
                 </li>
                 <li class="list-group-item">
                   所属角色：
                   <div class="pull-right">测试角色</div>
                 </li>
               </ul>
             </div>
           </div>
         </div>
      </div>
      <!--修改信息-->
      <div class="el-col el-col-18 el-col-xs-24 item-box">
        <div class="el-card is-always-shadow">
          <div class="el-card__header">
            <div class="clearfix">
              <span>基本信息</span>
            </div>
          </div>
          <div class="el-card__body">
            <el-form :model="ruleForm" :rules="rules" ref="ruleForm" label-width="100px" size="mini">
              <el-form-item label="账号名称：" style="font-weight: 700">
                <el-input v-model="ruleForm.account" :disabled="true"></el-input>
              </el-form-item>
              <el-form-item prop="nickname" label="用户昵称：" autocomplete="off" style="font-weight: 700">
                <el-input v-model="ruleForm.nickname"></el-input>
              </el-form-item>
              <el-form-item prop="oldPwd" label="旧密码：" autocomplete="off" style="font-weight: 700">
                <el-input show-password v-model="ruleForm.oldPwd"></el-input>
              </el-form-item>
              <el-form-item prop="newPwd" label="新密码：" autocomplete="off" style="font-weight: 700">
                <el-input show-password v-model="ruleForm.newPwd"></el-input>
              </el-form-item>
              <el-form-item prop="confirmPwd" label="确认密码：" autocomplete="off" style="font-weight: 700">
                <el-input show-password v-model="ruleForm.confirmPwd"></el-input>
              </el-form-item>
              <el-form-item>
                <el-button type="primary" @click="submitForm(ruleForm)">保存</el-button>
                <el-button @click="close">关闭</el-button>
              </el-form-item>
            </el-form>
          </div>
        </div>
      </div>
      <!--切换主题-->
      <div  class="el-col el-col-6 el-col-xs-24 item-box">
        <div class="el-card box-card is-always-shadow" style="height: 300px; margin-top: 15px">
          <div class="el-card__header">
            <div class="clearfix">
              <span>主题切换</span>
            </div>
          </div>
          <div class="el-card__body">
            <div>
              <el-select v-model="themeV" placeholder="请选择">
                <el-option
                  v-for="item in options"
                  :key="item.key"
                  :label="item.name"
                  :value="item.key">
                </el-option>
              </el-select>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
  import {themeList} from '@/assets/theme/setTheme.js';
  import {mapGetters} from 'vuex'
  import api from '@/api/'

  export default {
    data () {
      return {
        themeV: '',
        options: themeList,
        activeName: 'first',
        ruleForm: {
          account: '',
          nickname: '',
          oldPwd: '',
          newPwd: '',
          confirmPwd: ''
        },
        rules: {
          nickname: [
            { required: true,
              type: 'string',
              message: '请输入昵称',
              trigger: 'blur' }
            ],
          oldPwd: [
            { required: true, message: '请输入旧密码', trigger: 'blur' },
            { min: 8, message: '长度不少于 8 个字符', trigger: 'blur' },
            {pattern: /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{7,63}$/, message: '密码必须包含大小写字母、数字、下划线组合', trigger: 'blur'}
          ],
          newPwd: [
            { required: true, message: '请输入新密码', trigger: 'blur' },
            { min: 8, message: '长度不少于 8 个字符', trigger: 'blur' },
            {pattern: /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{7,63}$/, message: '密码必须包含大小写字母、数字、下划线组合', trigger: 'blur'}
          ],
          confirmPwd: [
            { required: true, message: '请输入确认密码', trigger: 'blur' },
            { min: 8, message: '长度不少于 8 个字符', trigger: 'blur' },
            {pattern: /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{7,63}$/, message: '密码必须包含大小写字母、数字、下划线组合', trigger: 'blur'}
          ]
        }
      }
    },
    computed: {
      ...mapGetters([
        'theme'
      ])
    },
    watch: {
      themeV(d) {
        this.changeTheme(d)
      }
    },
    created() {
      this.themeV = this.theme;
      this.getUserDetailsInfo()
    },
    methods: {
      /**
       * 切换主题
       * @param d
       */
      changeTheme(d) {
        this.$store.dispatch('ChangeTheme', d)
      },
      /**
       * 获取用户详情
       */
      getUserDetailsInfo() {
        // todo 获取用户详情信息，设置用户信息
      },
      /**
       * 提交编辑信息 todo: 待调试
       */
      submitForm(ruleForm) {
        console.log(ruleForm, '提交信息')
        // 提交信息时，先校验输入内容
        this.$refs.ruleForm.validate((valid) => {
          if (valid) {
            // 向后台发送请求
            api.Modify(ruleForm).then(res => {
              console.log(res)
              if (res.state.code === '0') {
                this.$notify({
                  title: '提示',
                  message: '修改成功',
                  type: 'success'
                });
              } else {
                this.$notify.error({
                  title: '错误',
                  message: '修改失败'
                });
              }
            }).catch(error => {
              console.log(error)
            })
          } else {
            // 就像用户提示发生错误的消息
          }
        })
      },
      /**
       * 关闭
       */
      close() {
        window.history.back();
      }
    }
  }
</script>

<style scoped>
.warp-box {
  padding: 20px;
  height: calc(100% - 82px);
  min-height: calc(100vh - 150px);
}
.item-box {
  padding: 0 10px 0 10px;
}
.text-center {
  text-align: center;
}
.list-group {
  padding-left: 0;
  list-style: none;
}
.list-group-striped .list-group-item {
  border-left: 0;
  border-right: 0;
  border-radius: 0;
  padding-left: 0;
  padding-right: 0;
}
.list-group-item {
  border-bottom: 1px solid #e7eaec;
  border-top: 1px solid #e7eaec;
  margin-bottom: -1px;
  padding: 11px 0;
  font-size: 13px;
}
.pull-right {
  float: right!important;
}

.user-avator {
  margin: 0 20px 10px 0;
}

.user-avator img {
  width: 120px;
  height: 120px;
  border-radius: 50%;
}
</style>
