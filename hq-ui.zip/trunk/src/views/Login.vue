<template>
  <div class="login-wrap">
    <div class="ms-login">
      <div class="ms-title">账号登录</div>
      <el-form :model="ruleForm" :rules="rules" ref="ruleForm" label-width="0px" class="ms-content">
        <el-form-item prop="account">
          <el-input v-model="ruleForm.account" placeholder="用户名">
          </el-input>
        </el-form-item>
        <el-form-item prop="pwd">
          <el-input type="password" placeholder="密码" v-model="ruleForm.pwd">
            <!--@keyup.enter.native="submitForm('ruleForm')">-->
          </el-input>
        </el-form-item>
        <el-form-item prop="code">
          <el-input size="small" style="width: 60%" v-model="ruleForm.code" placeholder="验证码" @keyup.enter.native="submitForm('ruleForm')"></el-input>
          <div class="el-input" style="width: 36%; display: inline-block">
            <img style="position: absolute;top: -21px; right: -5px" :src="srcImg" @click="getSrcImage">
          </div>
        </el-form-item>
        <div class="login-btn">
          <el-button type="primary" @click="submitForm('ruleForm')">登录</el-button>
        </div>
      </el-form>
    </div>
  </div>
</template>

<script>
  export default {
    data: function () {
      return {
        srcImg: '',
        ruleForm: {
          account: '',
          pwd: '',
          code: ''
        },
        rules: {
          account: [
            {required: true, message: '请输入用户名', trigger: 'blur'}
          ],
          pwd: [
            {required: true, message: '请输入密码', trigger: 'blur'}
          ],
          code: [
            {required: true, message: '请输入验证码', trigger: 'blur'}
          ]
        }
      }
    },
    created() {
      sessionStorage.setItem('clientId',this.Utils.guid())
      // 直接访问的登陆页要执行logout相关操作
      this.$store.dispatch('Logout')
      console.log(this.Utils.guid())
    },
    mounted() {
      // 获取验证码
      this.getSrcImage();
    },
    methods: {
      /**
       * 获取验证码
       */
      getSrcImage() {
        this.$store.dispatch('GetCaptcha').then((res) => {
          if (res.state.code == 0) {
            this.srcImg = res.data.captcha
          }
        }).catch((msg) => {
          this.$message({
            showClose: true,
            type: 'error',
            message: msg
          });
        });
      },
      submitForm(formName) {
        this.$refs[formName].validate((valid) => {
          if (valid) {
            let data = {
              account: this.ruleForm.account,
              pwd: this.Utils.md5(this.ruleForm.pwd),
              code: this.ruleForm.code
            };
            this.$store.dispatch('GetUserInfo', data).then((res) => {
              this.$message.closeAll();
              this.$router.push('/');
            }).catch((res) => {
              this.$message({
                showClose: true,
                type: 'error',
                message: res.state.message
              });
              this.getSrcImage();
            });
          } else {
            return false;
          }
        });
      }
    }
  }
</script>

<style scoped>
  .login-wrap {
    position: relative;
    width: 100%;
    height: 100%;
    background: url(../assets/img/background.png) no-repeat center center / cover;
  }

  .ms-title {
    width: 100%;
    line-height: 50px;
    text-align: center;
    font-size: 20px;
    color: black;
    border-bottom: 1px solid #ddd;
  }

  .ms-login {
    position: absolute;
    left: 75%;
    top: 50%;
    width: 350px;
    margin: -190px 0 0 -175px;
    border-radius: 5px;
    background: #fff;
    overflow: hidden;
  }

  .ms-content {
    padding: 30px 30px;
  }

  .login-btn {
    text-align: center;
  }

  .login-btn button {
    width: 100%;
    height: 36px;
    margin-bottom: 10px;
  }

  .login-tips {
    font-size: 12px;
    line-height: 30px;
    color: #fff;
  }
</style>
