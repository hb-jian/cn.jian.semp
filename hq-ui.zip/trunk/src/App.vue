<template>
  <div id="app" class="wh">
    <router-view/>
  </div>
</template>

<script>
    export default {
        name: 'App',
        computed: {},
        created() {
        }
    }
</script>

<style lang="scss">
  @import './assets/styles/main';
</style>
