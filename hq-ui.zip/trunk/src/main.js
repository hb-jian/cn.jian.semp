import Vue from 'vue'
import ElementUI from 'element-ui'
// element 样式
import 'element-ui/lib/theme-chalk/index.css'
// 阿里巴巴矢量图标
import './assets/iconfont/iconfont.css'
import * as echarts from 'echarts';
// axios 请求
import axios from 'axios';
import * as date from './util/date.js';
import apiexist from './util/apiexist';
import router from './router'
import store from './store/store.js'
import * as Utils from './util/utils.js'
import bus from 'vue-bus'
import App from './App.vue'
import moment from 'moment'
import 'moment/locale/zh-cn'

//挂载到VUE
Vue.prototype.Utils = Utils

// 允许跨域携带cookie信息
axios.defaults.withCredentials = true
// axios 请求拦截器
// axios.interceptors.request.use(
//   config => {
//       let token = sessionStorage.getItem('token')
//       if(!token || token == 'undefined'){
//           token = ''
//       }
//       config.headers.Authorization = 'Bearer ' + token
//       if (sessionStorage.getItem('user') != null) {
//           config.headers.butelidentity = JSON.parse(sessionStorage.getItem('user')).butelIdentity
//       }
//       return config
//   },
//   error => {
//       return Promise.reject(error)
//   }
// )
//
// axios 响应拦截器
axios.interceptors.response.use(response => {
  if (response.status == 200) {
    if (response.data.state.code == -99000) {
      Vue.prototype.$message({
        message: '未授权的操作,请重新登录',
        type: 'warning'
      });
      window.location.href = location.origin + '/app/login'
    }
    if (response.data.state.code == -99001) {
      Vue.prototype.$message({
        message: 'Token已过期,请重新登录',
        type: 'warning'
      });
      window.location.href = location.origin + '/app/login'
    }
    if (response.data.state.code == -99002) {
      Vue.prototype.$message({
        message: 'Token已禁用,请重新登录',
        type: 'warning'
      });
      window.location.href = location.origin + '/app/login'
    }
    if (response.data.state.code == -99003) {
      Vue.prototype.$message({
        message: '无效的授权信息,请重新登录',
        type: 'warning'
      });
      window.location.href = location.origin + '/app/login'
    }
  }
  return response
}, error => {
  return Promise.reject(error)
})

// 页面刷新时，重新赋值
if (window.sessionStorage.getItem('userData')) {
  let data = JSON.parse(window.sessionStorage.getItem('userData'));
  store.commit('SET_INFO', {name: data.name, id: data.id})
  store.dispatch('ChangeTheme', data.theme)
}

// 设置全局路由守卫
router.beforeEach(({meta, path}, from, next) => {
  var {auth = true} = meta
  // let currentUrl = (path.replace('/app/','')).replace('/','.');
  // console.log(currentUrl) // 当前路由

  // true用户已登录， false用户未登录
  var isLogin = Boolean(store.state.user.info)
  if (auth && !isLogin && path !== '/app/login') {
    return next({path: '/app/login'})
  }
  next()
})

Vue.prototype.$echarts = echarts

Vue.use(ElementUI)
Vue.use(date)
Vue.use(bus)
Vue.use(apiexist)
Vue.config.productionTip = false

new Vue({
  router,
  store,
  render: h => h(App)
}).$mount('#app')
