// import {getUserInfo} from '@/api/login'
import {setTheme, defaultTheme} from '@/assets/theme/setTheme.js'
import api from '@/api/'
import {removeCache} from '@/util/utils.js'
const user = {
  state: {
    info: '',
    theme: defaultTheme
  },
  mutations: {
    SET_INFO: (state, info) => {
      state.info = info
    },
    SET_THEME: (state, theme) => {
      state.theme = theme
    }
  },

  actions: {
    /**
     * 获取验证码
     * @param commit
     * @param state
     * @param getCaptcha
     * @returns {Promise<any>}
     * @constructor
     */
    GetCaptcha({commit, state}, getCaptcha) {
      return new Promise((resolve, reject) => {
        api.Captcha({}).then(res => {
          resolve(res)
        }).catch(error => {
          reject(error)
        })
      })
    },
    /**
     * 登录：获取用户信息
     * @param commit
     * @param state
     * @param loginForm
     * @returns {Promise<any>}
     * @constructor
     */
    GetUserInfo({commit, state}, loginForm) {
      return new Promise((resolve, reject) => {
        api.Login(loginForm).then(res => {
          if (res.state.code == 0) {
            // 将用户信息存入store
            commit('SET_INFO', {name: res.data.name, id: res.id})
            if (res.theme === 'dark') {
              this.dispatch('ChangeTheme', res.theme)
            } else if (res.theme === 'black') {
              this.dispatch('ChangeTheme', res.theme)
            } else {
              this.dispatch('ChangeTheme', defaultTheme)
            }
            // 登录返回结果没有accountName 临时使用
            res.data.name = loginForm.account;
            // 将用户信息存到本地缓存
            sessionStorage.setItem('userData', JSON.stringify(res));
            // 遍历存储所有路由信息,用于路由守卫,权限判断
            let loginMenus = [];
            res.data.menus.forEach(item => {
              loginMenus.push(item.route)
              if (item.children.length > 0) {
                item.children.forEach(obj => {
                  loginMenus.push(obj.route)
                })
              }
            });
            sessionStorage.setItem('allMenus',JSON.stringify(loginMenus));
            resolve()
          } else {
            reject(res)
          }
        }).catch(error => {
          reject(error)
        })
      });
    },
    /**
     * 登出
     * @param commit
     * @param state
     * @constructor
     */
    Logout({commit, state}) {
      commit('SET_INFO', '')
      removeCache('userData')
      removeCache('clientId')
      removeCache('allMenus')
    },

    // 改变用户主题
    ChangeTheme({commit, state}, theme) {
      commit('SET_THEME', theme)
      setTheme(theme);
      // 将用户改变的主题数据，存到缓存的userData里
      let userData = JSON.parse(sessionStorage.getItem('userData'));
      sessionStorage.setItem('userData', JSON.stringify({...userData, theme: theme}));
      // 存到数据库（不方便mock所以省略）
    }
  }
}

export default user
