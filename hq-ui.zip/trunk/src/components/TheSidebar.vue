<template>
  <div class="sidebar">
    <el-menu class="sidebar-el-menu" :default-active="activeIndex" :collapse="collapse"
             unique-opened
             @select="selectFn">
      <template v-for="item in items">
        <template v-if="item.children">
          <el-submenu :index="item.name" :key="item.name">
            <template slot="title">
              <!--<i :class="['iconfont','mr5',item.icon]"></i><span slot="title">{{ getTitle(item) }}</span>-->
              <i>
                <img :src="item.icon"/>
              </i>
              <span slot="title" style="padding-left: 5px">{{ getTitle(item) }}</span>
            </template>
            <template v-for="subItem in item.children">
              <el-submenu v-if="subItem.children" :index="subItem.name" :key="subItem.name">
                <template slot="title">{{ getTitle(subItem) }}</template>
                <el-menu-item v-for="(threeItem,i) in subItem.children" :key="i" :index="threeItem.name">
                  {{ getTitle(threeItem)}}
                </el-menu-item>
              </el-submenu>
              <el-menu-item v-else :index="subItem.name" :key="subItem.name">
                {{ getTitle(subItem)}}
              </el-menu-item>
            </template>
          </el-submenu>
        </template>
        <template v-else>
          <el-menu-item :index="item.name" :key="item.name">
            <!--<i :class="['iconfont','mr5',item.icon]"></i><span slot="title">{{ getTitle(item)}}</span>-->
            <i>
              <img :src="item.icon"/>
            </i><span slot="title"> {{ getTitle(item)}}</span>
          </el-menu-item>
        </template>
      </template>
    </el-menu>
  </div>
</template>

<script>
  import {mapGetters} from 'vuex'

  export default {
    data() {
      return {
        collapse: false,
        // key为路由的name，value为路由的路径和title
        routeMap: {},
        activeIndex: '',
        // 定义菜单的结构，每个对象都需要有name
        items: []
      }
    },
    created() {
      this.items = this.getRouterMenu()
      this.activeIndex = this.$route.name
      // 通过 Event Bus 进行组件间通信，来折叠侧边栏
      this.$bus.$on('collapse', msg => {
        this.collapse = msg;
      })
      let pageList = this.getAllRoutes(this.$router.options.routes);
      let routeMap = {};
      for (let item of pageList) {
        if (item.name) {
          routeMap[item.name] = {path: item.path, title: item.meta.title}
        }
      }
      this.routeMap = routeMap
    },
    computed: {
      ...mapGetters([
        'userId', 'theme'
      ])
    },
    watch: {},
    methods: {
      getRouterMenu() {
        var navItems = [];
        var userData = this.Utils.getObjCache('userData');
        if (userData && userData.data && userData.data.menus && userData.data.menus.length > 0) {
          userData.data.menus.forEach((item, index) => {
            var subsArr = [];
            if (item.children.length > 0) {
              item.children.forEach((obj, idx) => {
                subsArr.push({
                  name: obj.route
                })
              })
            }
            var model = {
              icon: this.Utils.getMenuIcon(item.route),
              title: item.name,
              name: item.route
            };
            if (subsArr.length > 0) {
              model.children = subsArr
            }
            navItems.push(model)
          })
        }
        return navItems
      },
      getTitle(item) {
        if (item.children && item.children.length > 0) return item.title
        else return this.routeMap[item.name] && this.routeMap[item.name].title
      },
      // 选中菜单的方法
      selectFn(index, indexPath) {
        this.$router.push({name: index})
        this.activeIndex = index;
        // 如果是点击的菜单，把keepAlive的缓存清掉，使得从菜单点进去的页面都是没有缓存的
        this.$store.dispatch('clearKeepAlive')
      },
      // 递归查所有既有name又有path的路由
      getAllRoutes(list) {
        let allRoutes = []
        for (let item of list) {
          if (item.children) {
            allRoutes.push(...this.getAllRoutes(item.children))
          } else if (item.path && item.name) {
            allRoutes.push(item);
          }
        }
        return allRoutes;
      }
    }
  }
</script>

<style scoped>
  .sidebar {
    display: block;
    position: absolute;
    left: 0;
    top: 70px;
    bottom: 0;
    overflow-y: scroll;
    z-index: 1;
  }

  .sidebar::-webkit-scrollbar {
    width: 0;
  }

  .sidebar-el-menu:not(.el-menu--collapse) {
    width: 250px;
  }
  body .el-menu-item.is-active {
    color: white;
    background: #1D2838;
    font-size: 15px;
    font-weight: bold;
  }
  .sidebar > ul {
    height: 100%;
  }
</style>
