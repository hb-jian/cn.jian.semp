<template>
  <div class="modal-backdrop">
    <div class="modal">
      <div class="modal-header">
        <h3 style="font-weight: bold; font-size: 16px">菜单选择</h3>
      </div>
      <div class="modal-body">
        <div style="margin-left: 25px">
          <el-tree
            :data="menuTree"
            show-checkbox
            node-key="id"
            ref="tree"
            highlight-current
            @check="handleCheck"
            :props="defaultProps">
          </el-tree>
        </div>
      </div>
      <div class="modal-footer">
        <el-button size="small" @click="closeSelf">关闭</el-button>
        <el-button size="small" type="primary" @click="confirm">确认</el-button>
      </div>
    </div>
  </div>
</template>

<script>
  import api from '@/api/'

  export default {
    name: "selectMenuModal",
    props: ['selectedData'],
    data() {
      return {
        menuTree: [],
        selectTreeData: this.selectedData,
        halfSelectData: [],
        defaultProps: {
          children: 'children',
          label: 'label'
        }
      }
    },
    created() {
      // 获取菜单树数据
      this.getMenuTree();
    },
    mounted() {
    },
    methods: {
      /**
       * @param data
       * @param selectedModel
       */
      handleCheck(data,selectedModel) {
        console.log(data,selectedModel)
        this.selectTreeData = selectedModel.checkedKeys

        if (selectedModel.halfCheckedKeys.length > 0) {
          this.halfSelectData = selectedModel.halfCheckedKeys
        }else {
          this.halfSelectData = [];
        }
      },

      /**
       * 初始获取菜单树 数据
       */
      getMenuTree() {
        api.getMenus({}).then(res => {
          if (res.state.code == 0) {
            this.menusDataMap(res.data)
            this.$nextTick(function () {
              // 设置默认选中数据
              this.$refs.tree.setCheckedKeys(this.selectTreeData);
              this.halfSelectData = this.$refs.tree.getHalfCheckedKeys();
            })
          } else {
            this.$message({
              message: '接口调用失败，' + res.state.message,
              type: 'error'
            });
          }
        })
      },
      /**
       * 数据处理
       *  @param data
       */
      menusDataMap(data) {
        if (data.length > 0) {
          data.forEach((item, idx) => {
            var model = {
              id: item.id,
              label: item.name,
              parentId: item.parentId,
              route: item.route,
              sort: item.sort
            };
            if (item.children && item.children.length > 0) {
              model.children = this.childrenMap(item.children)
            }
            this.menuTree.push(model)
          })
        }
      },
      /**
       * 子菜单处理
       * @param data
       */
      childrenMap(data) {
        var arr = [];
        if (data.length > 0) {
          data.forEach((item, idx) => {
            let model = {
              id: item.id,
              label: item.name,
              parentId: item.parentId,
              route: item.route,
              sort: item.sort
            };
            if (item.children && item.children.length > 0) {
              model.children = this.childrenMap(item.children)
            }
            arr.push(model)
          })
        }
        return arr
      },
      /**
       * 确认
       */
      confirm() {
        var model = {
          data: this.menuTree,
          selectData: this.selectTreeData
        };
        this.$emit("confirmSelected", this.selectTreeData,this.halfSelectData);
      },
      /**
       * 取消
       */
      closeSelf() {
        this.$emit("closeme");
      }
    }
  }
</script>

<style scoped>
  .modal-backdrop {
    position: fixed;
    top: 0;
    right: 0;
    bottom: 0;
    left: 0;
    background-color: rgba(0, 0, 0, .7);
    display: flex;
    justify-content: center;
    align-items: center;
  }

  .modal {
    background-color: #fff;
    box-shadow: 2px 2px 20px 1px;
    overflow-x: auto;
    display: flex;
    flex-direction: column;
    border-radius: 4px;
    width: 700px;
    height: 500px;
  }

  .modal-header {
    border-bottom: 1px solid #eee;
    color: #313131;
    justify-content: space-between;
    padding: 15px;
    display: flex;
  }

  .modal-footer {
    border-top: 1px solid #eee;
    justify-content: flex-end;
    padding: 15px;
    display: flex;
  }

  .modal-body {
    height: 400px;
    position: relative;
    padding: 20px 10px;
  }
</style>
