<template>
  <div class="modal-backdrop" style="z-index: 10000">
    <div class="modal">
      <div class="modal-header">
        <h3 style="font-weight: bold; font-size: 16px">企业选择</h3>
      </div>
      <div class="modal-body">
        <el-table
          ref="multipleTable"
          :data="tableData"
          tooltip-effect="dark"
          style="width: 100%"
          height="calc(100% - 52px)"
          @select-all="dialogCheck"
          @select="dialogCheck"
          @selection-change="handleSelectionChange">
          <el-table-column
            type="selection"
            width="55">
          </el-table-column>
          <el-table-column
            prop="name"
            label="企业名称">
          </el-table-column>
        </el-table>
        <div class="pagination-box">
          <el-button size="small" @click="cancel">关闭</el-button>
          <el-button size="small" type="primary" @click="submit">确认</el-button>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
  import api from '@/api/'
  export default {
    name: "selectEnterpriseItem",
    props: ['selectedData'],
    data() {
      return {
        tableData: [],
        selectItem: null
      }
    },
    created() {
      this.initData()
    },
    mounted() {

    },
    methods: {
      dialogCheck(selection, row) {
        this.$refs.multipleTable.clearSelection()
        if (selection.length === 0) {
          // 判断selection是否有值存在
          return
        }
        if (row) {
          this.selectItem = row;
          this.$refs.multipleTable.toggleRowSelection(row, true)
        }
      },
      handleSelectionChange(rows) {
      },
      /**
       * 默认选中数据
       */
      getSelectedItem(dataArr, val) {
        let model = null
        dataArr.forEach((item,index) => {
          if (item.id === val.id) {
            model = this.selectItem = item
          }
        });
        return model
      },
      /**
       *  初始化数据
       */
      initData() {
        let data = {pageIndex: 1, pageCount: 100000}
        api.OrgList(data).then( res => {
          if (res.state.code == 0) {
            this.tableData = res.pagingRows.rows
            console.log(this.selectedData,'===xxx==')
            if (this.selectedData) {
              console.log(this.getSelectedItem(this.tableData,this.selectedData),'=====')
              this.$nextTick(function () {
                this.$refs.multipleTable.toggleRowSelection(this.getSelectedItem(this.tableData,this.selectedData),true);
              })
            }
          } else {
            this.$message({
              message: '接口调用失败' + res.state.message,
              type: 'error'
            });
          }
        })
      },
      /**
       * 取消
       */
      cancel() {
        this.$emit("closed");
      },
      /**
       * 提交
       */
      submit() {
        this.$emit("confirmSelected", this.selectItem);
      }
    },
  }
</script>

<style scoped>
  .modal-backdrop {
    position: fixed;
    top: 0;
    right: 0;
    bottom: 0;
    left: 0;
    background-color: rgba(0, 0, 0, .7);
    display: flex;
    justify-content: center;
    align-items: center;
  }

  .modal {
    background-color: #fff;
    box-shadow: 2px 2px 20px 1px;
    overflow-x: auto;
    display: flex;
    flex-direction: column;
    border-radius: 4px;
    width: 700px;
    height: 500px;
  }

  .modal-header {
    border-bottom: 1px solid #eee;
    color: #313131;
    justify-content: space-between;
    padding: 15px;
    display: flex;
  }

  .modal-footer {
    border-top: 1px solid #eee;
    justify-content: flex-end;
    padding: 15px;
    display: flex;
  }

  .modal-body {
    height: 400px;
    position: relative;
    padding: 20px 10px;
  }

  .pagination-box {
    height: 52px;
    padding: 24px 20px 0 0;
    float: right;
  }
</style>
