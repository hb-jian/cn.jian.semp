<template>
  <div class="box">
    <div class="item-title-box" @click="handleClick">
      <div :style="titleStyleObj" class="title-icon">
        <div class="img-box" >
          <img
            v-if="data.isFolder && !isLoading"
            :style="{transform: `rotate(${isSpread ? -180 : 0}deg)`}"
            :src="require(`@/assets/img/down.png`)" width="16" height="16">
          <i v-if="data.isFolder && isLoading" class="el-icon-loading"></i>
        </div>
        <div class="name-box">
          <span v-if="data.isFolder">{{data.name}}</span>
          <div v-else class="item-name">
            <div class="check-box" v-if="root.showSelect">
              <div>
                <div :class="disabled ? 'ch-disabled' : ''" class="check-item check-box-normal" v-if="!data.isChecked"></div>
                <div :class="disabled ? 'ch-disabled' : ''" v-else class="check-item check-box-checked">
                  <i class="el-icon-check"></i>
                </div>
              </div>
            </div>
            <span :class="isOnline ? 'online' : 'offline'">{{data.name}}</span>
          </div>
        </div>
      </div>
      <div v-if="true && data.isFolder && root.cIndex === 1" class="opt-icon">
        <span>{{data.onlineCount}}</span>
        <span>/{{data.memberCount}}</span>
      </div>
    </div>
    <div ref="childBox" @transitionend="handleTransitionEnd" :style="childStyle" class="children-box">
      <tree-item v-for="(item) in children" :key="item.id" :data="item" :level="level + 1"></tree-item>
    </div>
  </div>
</template>

<script>
  import api from '@/api/'
  import { getQueryString } from '@/util/utils.js'
  export default {
    name: 'treeItem',
    props: {
      data: [Object],
      level: {
        type: Number,
        default: 0
      },
      showOnline: {
        type: Boolean,
        default: false
      },
      showPushing: {
        type: Boolean,
        default: false
      }
    },
    data() {
      return {
        children: [],
        isSpread: false,
        childBoxHeight: 0,
        childStyle: {},
        hasData: false,
        lastTime: 0,

        isOnline: false,
        isLiving: false,
        isSelected: false,
        isLoading: false
      }
    },
    watch: {
      'data.isChecked'() {
        const list = this.root.selectedList
        if(!this.data.isFolder) {
          if(this.data.isChecked) {
            list.push(this.data)
          } else {
            const index = list.findIndex(i => i == this.data)
            list.splice(index, 1)
          }
        }
      }
    },
    computed: {
      checked: {
        get() {
          return this.data.isChecked
        },
        set(val) {
          this.data.isChecked = val
        }
      },
      titleStyleObj() {
        return {
          paddingLeft: `${this.level * 15 + 10}px`
        }
      },
      disabled() {
        const urls = this.data.playUrls
        const hasPlayUrl = urls
          && Array.isArray(this.data.playUrls)
          && urls.length > 0
          && urls[1].url
        return (!this.data.isFolder && this.root.disableFlag && !hasPlayUrl) || this.root.disableAll
      }
    },
    mounted() {
      if(this.level == 0 && this.root.cIndex == 1) {
        this.handleClick()
      }
    },
    created() {
      // this.children = this.data.children
      // this.addCntToRoot()
      // let i = this.data.playUrls
      // if(i && i[0] && this.root.selectedMonitorList.includes(i[0])) {
      //   this.isSelected = true
      // }
    },
    inject: ['root'],
    methods: {
      removeItem(id){
        if(this.data.id === id) {
          this.data.isChecked = false
        }
      },
      addCntToRoot() {
        if(!this.data.isFolder) {
          this.root.setMembers(this.data.id, {
            child: this,
            data: this.data
          })
        }
      },
      updateOnlineState(item) {
        if(item.isOnline && item.isLiving) {
          this.data.playUrl = item.playUrl
        }
        const { isLiving, isOnline } = item
        this.isOnline = !!isOnline
        this.isLiving = !!isLiving
      },
      handlePushing(e) {
        e.stopPropagation()
        this.root.pushingClick(this.data)
      },
      handleOnline(e) {
        e.stopPropagation()
      },
      toggleChildren() {
        //  收起
        if(this.isSpread) {
          this.childBoxHeight = this.$refs.childBox.offsetHeight
          this.setTransitionHeight(this.childBoxHeight, 0)
        } else {
          //  打开
          let height = this.childBoxHeight
            ? this.childBoxHeight
            : (this.children ? this.children.length * 48 : 0)
          this.setTransitionHeight(0, height)
        }
        this.isSpread = !this.isSpread
      },
      setHeight(h) {
        this.childStyle = {
          height: `${h}px`
        }
      },
      setTransitionHeight(currentHeight, targetHeight) {
        this.setHeight(currentHeight)
        setTimeout(() => {
          this.setHeight(targetHeight)
        }, 20)
      },
      toggleBox() {
        if(this.data.isFolder) {
          this.toggleChildren()
          //  每次打开子列表，刷新子项的在线状态
          this.flushingState()
        }
      },
      flushingState() {
        //  子元素渲染完成后，获取列表状态
        setTimeout(() => this.root.flushingState())
      },
      async handleClick() {
        if(Date.now() - this.lastTime > 220) {
          this.lastTime = Date.now()
          if(!this.hasData) {
            this.isLoading = true
            if(this.data.isFolder) {
              this.children = await this.root.getList(this.data.id)
              this.hasData = true
              this.isLoading = false
            }
            this.toggleBox()
          } else {
            this.toggleBox()
          }

          //  禁止选择状态下，返回
          if(this.disabled) return

          //  item点击事件
          this.data.isChecked = !this.data.isChecked
          this.root.itemClick(this.data)

          //  在点击目录时，更新当前目录的当前在线人数，（仅在通讯录中显示总人数与在线人数）
          if(this.data.isFolder && this.root.cIndex === 1) {
            let data = {
              deptIds: [this.data.id],
            };

            if (getQueryString('token')) {
              data.token = getQueryString('token');
            }
            let res = await api.refreshcount(data);
            if(res.code === 0) {
              const {memberCount, onlineCount} = res.node[0]
              this.data.memberCount = memberCount
              this.data.onlineCount = onlineCount
            }
          }
        }
      },
      handleTransitionEnd() {
        if(this.isSpread) {
          this.childStyle = {}
        }
      }
    }
  }
</script>

<style lang="less" scoped>
  @transTime: .2s;
  .ct {
    display: flex;
    align-items: center;
    justify-content: center;
  }
  .img-box {
    width: 16px;
    height: 20px;
    margin-right: 5px;
    .ct();
    img {
      transition: transform @transTime linear;
    }
  }
  .box {
    user-select: none;
    color: #A9DDEE;
    font-size: 14px;
    .item-title-box {
      height: 48px;
      display: flex;
      align-items: center;
      margin-bottom: 1px;
      background: rgba(28, 159, 190, 0.2);
      &:hover, &.active {
        background: rgba(28, 159, 190, 0.1);
      }
      .title-icon {
        display: flex;
      }
      &>div:first-child {
        flex-grow: 1;
      }
      &>div:last-child {
        width: 50px;
        img {
          margin-right: 5px;
          cursor: pointer;
        }
      }
      .name-box {
        display: flex;
        align-items: center;
        .item-name {
          display: flex;
          align-items: center;
          height: 18px;
          line-height: 18px;
          img {
            margin-right: 10px;
          }
          .online {
            color: #01D4F9;
          }
          .offline {
            color: #A9DDEE;
          }
          .check-box {
            border-radius: 2px;
            margin-right: 5px;
            cursor: pointer;
            .check-item {
              width: 14px;
              height: 14px;
              text-align: center;
              line-height: 14px;
              border-radius: 2px;
            }
            .check-box-normal {
              border: 1px solid #dcdfe6;
              background: #fff;
              &:hover {
                border-color: #0BD2FF;
              }
            }
            .check-box-checked {
              border: 1px solid #0BD2FF;
              background: #0BD2FF;
              color: #fff;
            }
            .check-box-normal.ch-disabled {
              background: #666;
              color: #333;
              border-color: #666;
              cursor: not-allowed;
            }
            .check-box-checked.ch-disabled {
              background: #666;
              color: #333;
              border-color: #666;
              cursor: not-allowed;
            }
          }
        }
      }
    }
    .children-box {
      overflow: hidden;
      transition: height @transTime linear;
    }
  }
  .opt-icon {
    display: flex;
    justify-content: center;
    align-items: flex-end;
    &>span:first-child {
      color: #01D4F9;
      font-size: 18px;
    }
  }
</style>
