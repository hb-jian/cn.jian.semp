<template>
  <div class="menu-box-wrapper">
    <div class="header" ref="header" v-if="showHeader">
      <div :class="isActive(1)">群组</div>
    </div>
    <div class="menu-list" :style="{height: `${height}`}">
      <div>
        <tree-item v-for="(item) in group.list" :key="item.id" :data="item"></tree-item>
      </div>
    </div>
  </div>
</template>

<script>
  import treeItem from './Item'
  import api from '@/api/'
  import { getQueryString } from '@/util/utils.js'
  export default {
    props: {
      canSelect: {
        type: Boolean,
        default: false
      },
      showHeader: {
        type: Boolean,
        default: true
      },
      selectAble: {
        type: Boolean,
        default: false
      },
      ifShowMonitor: {
        type: Boolean,
        default: true
      },
      boxHeight: {
        type: String | Number,
        default: ''
      },
      showPushing: {
        type: Boolean,
        default: false
      },
      ifUpdateState: {
        type: Boolean,
        default: true
      },
      defaultType: {
        type: Number
      },
      selectedMonitorList: {
        type: Array,
        default: () => []
      },
      isMonitor: {
        type: Boolean,
        default: false
      },
      disableFlag: {
        type: Boolean,
        default: false
      },
      disableAll: {
        type: Boolean,
        default: false
      },
      showSelect: {
        type: Boolean,
        default: true
      },
      selectedItemList: {
        type: Array,
        default: () => []
      }
    },
    provide() {
      return {
        root: this
      }
    },
    data() {
      function initListData() {
        return {
          list: [],
          hasData: false
        }
      }
      return {
        cIndex: 1,
        height: 0,
        treeData: [],
        department: initListData(),
        group: initListData(),
        monitor: initListData(),
        members: {},
        selectedList: [],
        isLogin: false
      }
    },
    methods: {
      removeChecked(id) {
        function broadcast(component, id) {
          component.$children.forEach(child => {
            child.removeItem(id)
            broadcast(child, id)
          })
        }
        broadcast(this, id)
      },

      getSelectedList() {
        return this.selectedList
      },

      setMembers(key, val) {
        this.members[key] = val
      },

      //向父组件传参
      sendLoginStatusToShowMap(val) {
        this.$emit('sendLoginStatusToShowMap',val)
      },

      updateData(val) {
        if (val) {
          const type = this.defaultType !== undefined ? this.defaultType : 1
          let map = {
            1: 'department',
            2: 'group',
            3: 'monitor'
          }
          //  有缓存数据，不再请求
          let listType = map[type]
          this[listType].hasData = false
          this.handleTab(type)
        }
      },

      flushingState() {
        let keys = Object.keys(this.members)
        if(keys.length === 0) {
          return
        }
        let i = keys.length
        let queryList = []
        let monitorList = []

        while(i--) {
          let data = this.members[keys[i]].data
          //  用户/设备
          if(data.type) {
            queryList.push({
              sid: data.id,
              // memberType: data.type,
              uniqueSign: data.uniqueSign
            })
          } else {
            //  摄像头
            monitorList.push({
              sid: data.id,
              liveCid: data.liveCid
            })
          }
        }

        let data = {
          takeTrack: false,
          takeLastPosition: false,
          members: queryList
        };
        //支持token
        if (getQueryString('token')) {
          data.token = getQueryString('token');
        }

        if(queryList.length > 0) {
          this.updateChildState(api.refreshstatus(data))
        }
        if(monitorList.length > 0) {
          this.updateChildState(api.refreshMonitorStatus(monitorList))
        }
      },

      updateChildState(res) {
        res.then(res => {
          res.node.forEach(item => {
            this.members[item.sid].child.updateOnlineState(item)
          })
        })
      },

      handleTab(val) {
        this.cIndex = val
        let map = {
          1: 'department',
          2: 'group',
          3: 'monitor'
        }
        //  有缓存数据，不再请求
        let listType = map[val]
        if(this[listType].hasData) {
          return
        }
        //  首次请求数据
        this.getList().then(list => {
          this[listType].list = list
          this[listType].hasData = true
        })
      },

      itemClick(data) {
        this.$emit('itemClick', data)
      },

      pushingClick(data) {
        this.$emit('pushingClick', data)
      },

      isActive(val) {
        return val === this.cIndex ? 'active' : ''
      },

      formatDepartment(list, members) {
        let catalogs = list.map(item => {
          return this.formatFolder(
            item.deptName,
            item.deptId,
            item.children,
            true,
            item.memberCount,
            item.onlineCount
          )
        })
        let items = this.formatMembers(members)
        list = [...catalogs, ...items]
        list.forEach(item => item.isChecked = this.selectedItemList.includes(item.id))
        return list
      },

      formatGroup(list, members) {
        let catalogs = list.map(item => {
          return this.formatFolder(
            item.groupName,
            item.groupId,
            item.children,
            true,
            item.memberCount,
            item.onlineCount
          )
        })
        let items = this.formatMembers(members)
        list = [...catalogs, ...items]
        list.forEach(item => item.isChecked = this.selectedItemList.includes(item.id))
        return list
      },

      formatMonitor(list, members) {
        let catalogs = list.map(item => {
          return this.formatFolder(
            item.groupName,
            item.groupId,
            item.children,
            true,
            item.memberCount,
            item.onlineCount
          )
        })
        let items = this.formatMembers(members)
        list = [...catalogs, ...items]
        list.forEach(item => item.isChecked = this.selectedItemList.includes(item.id))
        return list
      },

      formatFolder(name, id, children, isFolder, memberCount, onlineCount) {
        return { name, id, children: children || [], isFolder, memberCount, onlineCount }
      },

      formatMembers(mems) {
        return mems.map(item => this.getFormatedItem(
          item.name,
          item.id,
          item.children,
          false,
          item.type,
          item.nube,
          item.uniqueSign,
          item.playUrls,
          item.liveCid,
          item.playUrl,
          item.deviceType
        ))
      },

      getFormatedItem(
        name,
        id,
        children,
        isFolder,
        type,
        nube,
        uniqueSign,
        playUrls,
        liveCid,
        playUrl,
        deviceType
      ) {
        const tmp = {
          name,
          id,
          children: children || [],
          isFolder,
          type,
          nube,
          uniqueSign,
          playUrls,
          liveCid,
          playUrl
        }
        deviceType && (tmp.deviceType = deviceType)
        return tmp
      },

      /**
       * 获取群组数据（部门下人员）
       */
      getGroupData(id) {
        let conProModel = {
          contactsType: 2,
          groupId: id ? id : '0'
        };
        let groupPro = null
        if (getQueryString('token')) {
          conProModel.token = getQueryString('token');
          groupPro = api.grouplist({token: getQueryString('token')})
        }else {
          groupPro = api.grouplist()
        }
        let conPro = api.contacts(conProModel)
        return Promise.all([groupPro, conPro]).then(res => {
          let [{node: list}, {node: members}] = res
          return this.formatGroup(id ? [] : list.rows, members.total > 0 ? members.rows : [])
        })
      },

      /**
       * 获取部门数据（子部门/部门下人员）
       */
      getDepartmentData(id) {
        let depPreModel = {
          parentId: id ? id : '0'
        };
        let conProModel = {
          contactsType: 1,
          deptId: id ? id : '0'
        };
        if (getQueryString('token')) {
          depPreModel.token = getQueryString('token');
          conProModel.token = getQueryString('token');
        }
        let depPro = api.deptlist(depPreModel)
        let conPro = api.contacts(conProModel)
        return Promise.all([depPro, conPro]).then(res => {
          let [department, contacts] = res;
          //登录失效，执行登录操作
          if (department.code === -10004) {
            this.sendLoginStatusToShowMap(true);
          }else if(Array.isArray(department.node) || department.node.length > 0) {
            this.sendLoginStatusToShowMap(false);
            return this.formatDepartment(department.node, contacts.node.total > 0 ? contacts.node.rows : [])
          }
        })
      },

      /**
       * 获取摄像头分组 / 摄像头
       */
      getMonitorList(id) {
        let listPro = api.monitorgroup({parentId: id ? id : '0'})
        let memberPro = id ? api.cameralist({groupId: id}) : Promise.resolve()
        return Promise.all([listPro, memberPro]).then(res => {
          let [listResm, memberRes] = res
          let list = listResm.node && listResm.node.rows ? listResm.node.rows : []
          let mems = []
          if(memberRes) {
            mems = memberRes.node && memberRes.node.rows || []
          }
          return this.formatMonitor(list, mems)
        })
      },

      getList(id) {
        if(this.cIndex == 1) {
          return this.getDepartmentData(id)
        } else if(this.cIndex == 2) {
          return this.getGroupData(id)
        } else if(this.cIndex == 3) {
          return this.getMonitorList(id)
        }
      }
    },
    created() {
      // const type = this.defaultType !== undefined ? this.defaultType : 1
      // this.handleTab(type)
      // if(this.ifUpdateState) {
      //   this.timer = setInterval(() => {
      //     this.flushingState()
      //   }, 1 * 1000)
      // }
      // this.$once('hook:destroyed', () => {
      //   if(this.timer != undefined) {
      //     clearInterval(this.timer)
      //   }
      // })
    },
    mounted() {
      if(this.boxHeight) {
        this.height = this.boxHeight - this.$refs.header.offsetHeight + 'px'
      } else {
        this.height = '100%'
      }
    },
    components: {
      treeItem
    }
  }
</script>

<style lang="less" scoped>
  .menu-box-wrapper {
    color: #fff;
    height: 100%;
    display: flex;
    flex-direction: column;
  }
  .header {
    height: 40px;
    display: flex;
    border-top: 1px solid #48A2B3;
    border-bottom: 1px solid #48A2B3;
    font-size: 16px;
    &>div {
      cursor: pointer;
      flex-grow: 1;
      background: #003B68;
      text-align: center;
      border-right: 1px solid #48A2B3;
      padding: 8px 0;
    }
    &>div:last-child {
      border: none;
    }
    &>div.active {
      background: linear-gradient(#2DBCDD, #1898B6, #2DBCDD);
    }
  }
  .menu-list {
    overflow: auto;
    background: rgba(28, 159, 190, 0.2);
  }
</style>
