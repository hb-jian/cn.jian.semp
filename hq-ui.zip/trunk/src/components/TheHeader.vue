<template>
  <div class="header" >
    <!-- 折叠按钮 -->
    <div class="collapse-btn" @click="collapseChage">
      <i class="el-icon-menu"></i>
    </div>
    <!--<div class="logo">华清智慧管理平台</div>-->
    <div class="logo">XXXXXX</div>
    <div class="header-right">
      <div class="header-user-con">
        <!-- 用户头像 -->
        <div class="user-avator"><img src="../assets/img/img.jpg"></div>
        <el-dropdown trigger="click">
          <span class="el-dropdown-link">
          {{accountName}}<i class="el-icon-arrow-down el-icon--right"></i>
          </span>
          <el-dropdown-menu slot="dropdown">
            <el-dropdown-item @click.native="gotoUserInfo">个人中心</el-dropdown-item>
            <el-dropdown-item  @click.native="logout">退出登录</el-dropdown-item>
          </el-dropdown-menu>
        </el-dropdown>
      </div>
    </div>
  </div>
</template>
<script>
  import {mapGetters} from 'vuex'
  import api from '@/api/'

  export default {
    data() {
      return {
        collapse: false,
        drawer: false,
        accountName: ''
      }
    },
    components: {
    },
    created() {
      // this.setTheme();
      this.accountName = JSON.parse(sessionStorage.getItem('userData')).data.name
    },
    computed: {
      ...mapGetters([
        'name', 'userId', 'theme'
      ])
    },
    watch: {
      // // 如果主题改变
      // theme() {
      //   this.setTheme();
      // }
    },
    methods: {
      gotoUserInfo() {
        this.$router.push('/app/userinfo');
      },
      // 侧边栏折叠
      collapseChage() {
        this.collapse = !this.collapse;
        this.$bus.$emit('collapse', this.collapse);
      },
      // 退出登录接口
      logout() {
        this.$confirm('您确定要退出系统码?', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          api.Logout().then(res => {
            if (res.state.code == 0) {
              sessionStorage.removeItem('clientId')
              this.$store.dispatch('Logout');
              this.$router.push('/app/login');
            } else {
              this.$message({
                showClose: true,
                message: res.state.message,
                type: 'error'
              })
            }
          })
        }).catch(() => {
        });
      }
    },
    mounted() {
      if (document.body.clientWidth < 1500) {
        this.collapseChage();
      }
    }
  }
</script>
<style scoped>
  .header {
    position: relative;
    box-sizing: border-box;
    width: 100%;
    height: 70px;
    font-size: 22px;
    color: #fff;
  }

  .collapse-btn {
    float: left;
    width: 63px;
    text-align: center;
    height: 100%;
    cursor: pointer;
    line-height: 70px;
  }

  .header .logo {
    float: left;
    margin-left: 20px;
    line-height: 70px;
  }

  .header-right {
    float: right;
    padding-right: 20px;
  }

  .header-user-con {
    display: flex;
    height: 70px;
    align-items: center;
    font-size: 16px;
  }

  .el-dropdown-link {
    margin: 0 20px 0 10px;
    cursor: pointer;
    color: white;
  }

  .user-name:hover {
    margin: 0 20px 0 10px;
    color: #c4c4c4;
  }

  .personal-center {
    margin: 0 20px 0 10px;
    padding: 25px;
  }

  .personal-center:hover{
    margin: 0 20px 0 10px;
    padding: 25px;
    background: #283446;
    color: #c4c4c4;
  }

  .user-avator {
    margin: 0 20px 10px 0;
  }

  .user-avator img {
    display: block;
    width: 40px;
    height: 40px;
    border-radius: 50%;
  }

  .user-logout {
    border: 1px solid #fff;
    border-radius: 18px;
    padding: 3px 18px;
    font-size: 14px;
  }

  .collapse-btn:hover {
    background: rgba(0, 0, 0, 0.15)
  }
</style>
