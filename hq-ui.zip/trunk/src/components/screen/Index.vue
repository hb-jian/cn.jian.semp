<template>
    <div class="screen-box-detail">
        <div class="no-signal"
            v-if="showVideo"
            @mouseenter="handleMouse(true)"
            @mouseleave="handleMouse(false)">
            <video controls ref="video" muted="muted"></video>
            <div v-if="showCameraInfo" class="info">
                <div>摄像头名称：前台监控</div>
                <div>位置：古城创业大厦B座9层</div>
                <div>登记时间：2020年2月2日 19:12:22</div>
                <div>推流方式：持续推流</div>
            </div>
            <div v-if="showCloseBtn"
                class="close-box"
                @click="handleClose"
                @mouseover="handleCloseHover(true)"
                @mouseout="handleCloseHover(false)">
                <img :src="closeBtn">
                <div>关闭</div>
            </div>
            <div v-if="showRefresh" class="refresh-box" @click="refreshVideo">
                <i class="el-icon-refresh"></i>
                <span>刷新</span>
            </div>
            <div v-if="showRefresh" class="monitor-name">{{info.name}}</div>
        </div>
        <div v-else
            @click="noSignalClick"
            class="no-signal border-box"
            :style="screenStyle">无信号</div>
    </div>
</template>

<script>
import Hls from 'hls.js'
export default {
    data() {
        return {
            closeBtn: require('@/assets/img/close.png'),
            showCloseBtn: false,
            showVideo: false,
            showCameraInfo: false,
            showRefresh: false,
            hls: null
        }
    },
    props: {
        info: {
            type: Object
        }
    },
    watch: {
        'info.url'(){
            this.showVideo = !!this.info.url
            this.showVideo && this.preperToPlay(this.info.url)
        },
        'info.name'() {
            // console.log(this.info)
        }
    },
    computed: {
        screenStyle() {
            return {
                background: `url(${require('@/assets/img/nosignal.png')})`,
                border: `1px solid ${this.info.selected ? '#00FFFF' : '#0B1557'}`
            }
        }
    },
    methods: {
        refreshVideo() {
            this.preperToPlay(this.info.url)
        },
        preperToPlay(url) {
            this.$nextTick(() => {
                if(this.hls !== null) {
                    this.hls.destroy()
                }
                const hls = this.hls = new Hls()
                hls.loadSource(url)
                hls.attachMedia(this.$refs.video)
                hls.on(Hls.Events.MANIFEST_PARSED, () => {
                    this.$refs.video.play()
                })
            })
        },
        handleCloseHover(val) {
            this.closeBtn = val ?
                require('@/assets/img/close_hover.png') :
                    require('@/assets/img/close.png')
        },
        handleMouse(val) {
            this.showCloseBtn = val
            this.showRefresh = val
        },
        handleClose() {
            //  关闭时，销毁hls实例
            this.hls.destroy()
            this.hls = null
            this.showVideo = false
            this.showCloseBtn = false
            this.handleCloseHover(false)
            this.$emit('screenClose', this.info)
            this.noSignalClick()
        },
        noSignalClick() {
            this.$emit('screenClick', this.info, this)
        }
    }
}
</script>

<style lang="less" scoped>
.screen-box-detail {
    width: 100%;
    height: 100%;
    background: #399;
    box-sizing: border-box;
    .border-box {
        box-sizing: 'border-box';
        cursor: pointer;
        text-shadow: 4px 4px 3px #000;
    }
    .no-signal {
        width: 100%;
        height: 100%;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 16px;
        position: relative;
        .monitor-name {
            font-size: 14px;
            position: absolute;
            left: 50%;
            transform: translateX(-50%);
            bottom: 5px;
            background: rgba(0, 0, 0, 0.5);
            padding: 5px;
            border-radius: 2px;
        }
        video {
            background: #000;
            width: 100%;
            height: 100%;
        }
        .info {
            width: 60%;
            height: 60%;
            background: rgba(0, 0, 0, 0.7);
            position: absolute;
        }
        .close-box {
            color: #A3A3A3;
            position: absolute;
            right: 10px;
            top: 10px;
            background: rgba(0, 0, 0, 0.6);
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 3px 8px;
            font-size: 14px;
            border-radius:2px;
            cursor: pointer;
            user-select: none;
            img {
                margin-right: 3px;
            }
            &:hover {
                color: #01D4F9;
            }
        }
        .refresh-box {
            position: absolute;
            right: 10px;
            top: 50px;
            background: rgba(0, 0, 0, 0.6);
            padding: 3px 8px;
            font-size: 14px;
            color: #A3A3A3;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            user-select: none;
            i {
                font-size: 22px;
            }
            &:hover {
                color: #01D4F9;
            }
        }
    }
}
</style>
