import Vue from 'vue'
import Router from 'vue-router'
// 在VUE中路由遇到Error: Avoided redundant navigation to current location:报错 处理路由重复
const originalPush = Router.prototype.push
Router.prototype.push = function push(location) {
  return originalPush.call(this, location).catch(err => err)
}

Vue.use(Router)

export default new Router({
  mode: 'history',
  routes: [
    {
      path: '/',
      redirect: '/app/dashboard'
    },
    {
      path: '/',
      name: 'menu',
      component: resolve => require(['../components/TheHome.vue'], resolve),
      children: [
        // 首页
        {
          path: '/app/dashboard',
          name: 'dashboard',
          component: resolve => require(['../views/Dashboard.vue'], resolve),
          meta: {title: '首页'}
        },

        // 个人中心
        {
          path: '/app/userinfo',
          name: 'userinfo',
          component: resolve => require(['../views/UserInfo.vue'], resolve),
          meta: {title: '个人中心'}
        },

        // 企业管理
        {
          path: '/app/enterprise',
          name: 'enterprise',
          meta: {title: '企业管理', type: 'sub'}
        },
        {
          path: '/app/enterprise/list',
          name: 'enterprise.list',
          component: resolve => require(['../views/Enterprise/EnterpriseList.vue'], resolve),
          meta: {title: '企业列表'}
        },

        // 项目管理
        {
          path: '/app/project',
          name: 'project',
          meta: {title: '项目管理', type: 'sub'}
        },
        {
          path: '/app/project/list',
          name: 'project.list',
          component: resolve => require(['../views/Project/ProjectList.vue'], resolve),
          meta: {title: '项目列表'}
        },

        // 用户管理
        {
          path: '/app/user',
          name: 'user',
          meta: {title: '用户管理', type: 'sub'}
        },
        {
          path: '/app/user/list',
          name: 'user.list',
          component: resolve => require(['../views/User/UserList.vue'], resolve),
          meta: {title: '用户列表'}
        },
        {
          path: '/app/user/role',
          name: 'user.role',
          component: resolve => require(['../views/User/UserRole.vue'], resolve),
          meta: {title: '用户角色'}
        },

        // 指挥中心
        {
          path: '/app/command',
          name: 'command',
          meta: {title: '指挥中心', type: 'sub'}
        },
        {
          path: '/app/command/digitallargescreen',
          name: 'command.digitallargescreen',
          component: resolve => require(['../views/command/digitalLargeScreen.vue'], resolve),
          meta: {title: '数字大屏'}
        },
        {
          path: '/app/command/monitoring',
          name: 'command.monitoring',
          component: resolve => require(['../views/command/monitoring.vue'], resolve),
          meta: {title: '监控中心'}
        },

        // 数据分析
        {
          path: '/app/statistics',
          name: 'statistics',
          meta: {title: '数据分析', type: 'sub'}
        },
        {
          path: '/app/statistics/performance',
          name: 'statistics.performance',
          component: resolve => require(['../views/Statistics/Performance.vue'], resolve),
          meta: {title: '统计报表'}
        },

         // 运营监控
        {
          path: '/app/operate',
          name: 'operate',
          meta: {title: '运营监控', type: 'sub'}
        },
        {
          path: '/app/operate/alarm',
          name: 'operate.alarm',
          component: resolve => require(['../views/Operate/Alarm.vue'], resolve),
          meta: {title: '监控告警'}
        },
        {
          path: '/app/operate/policy',
          name: 'operate.policy',
          component: resolve => require(['../views/Operate/Policy.vue'], resolve),
          meta: {title: '告警策略'}
        }
      ]
    },
    {
      path: '/app/login',
      component: resolve => require(['../views/Login.vue'], resolve)
    },
    {
      path: '*',
      component: resolve => require(['../views/404.vue'], resolve)
    }
  ]
})
