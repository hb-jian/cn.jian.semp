//  开发环境以及生产环境对应的不同的API
const isProduction = process.env.NODE_ENV == 'production' && process.env.VUE_APP_BD_ENV == 'production'
const apis = isProduction ? {
  apiHost: "http://81.70.164.251:20000/",
} : {
  apiHost: "http://81.70.164.251:20000/",
}

export default apis
