import axios from 'axios'
import apis from './api.config'

export function ajax(options) {
  if (!options.url) {
    throw new Error('url is required')
  }
  let opts = {
    url: options.url,
    method: options.method || 'get',
    headers: {
      'ClientId': sessionStorage.getItem('clientId'),
    }
  };

  //除登录接口外 其他接口均需要 请求头设置Authorization
  if (opts.url.indexOf('account/login') == -1) {
    opts.headers.Authorization = JSON.parse(sessionStorage.getItem('userData')).data.tokenType + ' ' + JSON.parse(sessionStorage.getItem('userData')).data.accessToken
  }
  const method = opts.method.toLowerCase();
  if (method === 'get') {
    opts.params = options.data
  } else if (method === 'post') {
    opts.data = options.data
  }

  return new Promise((resolve, reject) => {
    return axios(opts).then(res => {
      if (res.status === 200) {
          resolve(res.data)
      } else {
        alert('网络请求错误')
      }
    }).catch(err => {
      reject(err)
    })
  })
}

export default {

  // ↓↓↓↓↓↓↓↓↓↓ 账号管理 ↓↓↓↓↓↓↓↓↓↓
  /**
   * 登录
   */
  Login(data) {
    return ajax({
      method: 'post',
      url: apis.apiHost + 'api/account/login',
      data
    })
  },

  /**
   * 登出接口
   * @constructor /api/account/modify
   */
  Logout() {
    return ajax({
      method: 'post',
      url: apis.apiHost + 'api/account/logout'
    })
  },

  /**
   * 修改用户信息
   * @constructor
   */
  Modify(data) {
    return ajax({
      method: 'post',
      url: apis.apiHost + 'api/account/modify',
      data
    })
  },

  /**
   * 获取登录验证码
   * @constructor
   */
  Captcha(data) {
    return ajax({
      url: apis.apiHost + 'api/account/login/captcha',
      data
    })
  },

  /**
   * 用户注册接口
   * @constructor
   */
  Regist(data) {
    return ajax({
      method: 'post',
      url: apis.apiHost + 'api/account/regist',
      data
    })
  },

  /**
   * 用户注册接口
   * @constructor
   */
  AccountList(data) {
    return ajax({
      url: apis.apiHost + 'api/account/list',
      data
    })
  },
  // ↓↓↓↓↓↓↓↓↓↓ 角色管理 ↓↓↓↓↓↓↓↓↓↓
  /**
   * 角色列表
   * @param data
   */
  getRoleList(data) {
    return ajax({
      url: apis.apiHost + 'api/role/list',
      data
    })
  },

  /**
   * 创建角色
   * @constructor
   */
  RoleCreate(data) {
    return ajax({
      method: 'post',
      url: apis.apiHost + 'api/role/create',
      data
    })
  },

  /**
   * 修改登记【创建】
   * @constructor
   */
  RoleUpdate(data) {
    return ajax({
      method: 'post',
      url: apis.apiHost + 'api/role/update',
      data
    })
  },

  /**
   * 详情
   * @constructor
   */
  RoleGet(data) {
    return ajax({
      url: apis.apiHost + 'api/role/'+data.id,
    })
  },


  // ↓↓↓↓↓↓↓↓↓↓ 数据统计 ↓↓↓↓↓↓↓↓↓↓
  /**
   * 数据统计
   * @constructor
   */
  Summary(data) {
    return ajax({
      method: 'post',
      url: apis.apiHost + 'api/statistics/org/summary',
      data
    })
  },

  /**
   * proData
   * @constructor
   */
  Ts01(data) {
    return ajax({
      method: 'post',
      url: apis.apiHost + 'api/statistics/org/ts01',
      data
    })
  },

  // ↓↓↓↓↓↓↓↓↓↓ 机构管理 ↓↓↓↓↓↓↓↓↓↓

  /**
   * 分页列表
   * @constructor
   */
  OrgList(data) {
    return ajax({
      url: apis.apiHost + 'api/org/list',
      data
    })
  },

  /**
   * 机构登记【创建】
   * @constructor
   */
  OrgCreate(data) {
    return ajax({
      method: 'post',
      url: apis.apiHost + 'api/org/create',
      data
    })
  },

  /**
   * 机构更新【创建】
   * @constructor
   */
  OrgUpdate(data) {
    return ajax({
      method: 'post',
      url: apis.apiHost + 'api/org/update',
      data
    })
  },

  /**
   * 获取企业默认菜单
   * @param data
   */
  getMenus(data) {
    return ajax({
      url: apis.apiHost + 'api/org/menus',
      data
    })
  },

  /**
   * 详情
   * @constructor
   */
  OrgGet(data) {
    return ajax({
      url: apis.apiHost + 'api/org/'+data.id,
    })
  },

  // ↓↓↓↓↓↓↓↓↓↓ 监控管理 ↓↓↓↓↓↓↓↓↓↓

  /**
   * 查询项目负载
   * @constructor
   */
  MonitorProjectLoad(data) {
    return ajax({
      url: apis.apiHost + 'api/monitor/project/load',
      data
    })
  },

  // ↓↓↓↓↓↓↓↓↓↓ 设备管理 ↓↓↓↓↓↓↓↓↓↓

  /**
   * 设备分页列表
   * @param data
   * @constructor
   */
  DeviceList(data) {
    return ajax({
      url: apis.apiHost + 'api/device/list',
      data
    })
  },

  /**
   * 设备登记【创建】
   * @constructor
   */
  DeviceCreate(data) {
    return ajax({
      method: 'post',
      url: apis.apiHost + 'api/device/create',
      data
    })
  },

  /**
   * 设备更新【创建】
   * @constructor
   */
  DeviceUpdate(data) {
    return ajax({
      method: 'post',
      url: apis.apiHost + 'api/device/update',
      data
    })
  },

  /**
   * 在线状态
   * @constructor
   */
  DeviceStatus(data) {
    return ajax({
      url: apis.apiHost + 'api/device/status',
      data
    })
  },

  /**
   * 设备详情
   * @constructor
   */
  DeviceGet(data) {
    return ajax({
      url: apis.apiHost + 'api/device/'+data.id,
    })
  },

  // ↓↓↓↓↓↓↓↓↓↓ 项目管理 ↓↓↓↓↓↓↓↓↓↓

  /**
   * 项目分页列表
   * @param data
   * @constructor
   */
  ProjectList(data) {
    return ajax({
      url: apis.apiHost + 'api/project/list',
      data
    })
  },

  /**
   * 项目登记【创建】
   * @constructor
   */
  ProjectCreate(data) {
    return ajax({
      method: 'post',
      url: apis.apiHost + 'api/project/create',
      data
    })
  },

  /**
   * 项目更新【创建】
   * @constructor
   */
  ProjectUpdate(data) {
    return ajax({
      method: 'post',
      url: apis.apiHost + 'api/project/update',
      data
    })
  },

  /**
   * 项目详情
   * @constructor
   */
  ProjectGet(data) {
    return ajax({
      url: apis.apiHost + 'api/project/'+data.id,
    })
  }

}
