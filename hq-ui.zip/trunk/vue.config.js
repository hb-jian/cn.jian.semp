// const proxyObj = {}
// proxyObj['/'] = {
//   target: 'http://81.70.164.251:20000',
//   changeOrigin: true,
//   pathRewrite: {
//     '^/': ''
//   }
// }
// module.exports = {
//   devServer: {
//     host: '81.70.164.251',
//     port: 8291,
//     // proxy: proxyObj
//   }
// }
//
